#!/bin/bash
# CodeLens API Server 실행 스크립트

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 가상환경 활성화
if [ -d "venv" ]; then
    source venv/bin/activate
else
    echo "Error: venv not found. Run './install-linux.sh' first."
    exit 1
fi

# 로그 디렉토리 생성
mkdir -p logs

# config/settings.yaml의 server 섹션에서 설정 읽기
HOST=$(awk '/^server:/,/^[a-z]/{if(/host:/) print $2}' config/settings.yaml | head -1)
PORT=$(awk '/^server:/,/^[a-z]/{if(/port:/) print $2}' config/settings.yaml | head -1)
WORKERS="${CODELENS_WORKERS:-1}"
LOG_LEVEL="${CODELENS_LOG_LEVEL:-info}"

# 기본값 설정
HOST="${HOST:-0.0.0.0}"
PORT="${PORT:-8080}"

echo "Starting CodeLens Server..."
echo "  Host: $HOST"
echo "  Port: $PORT"
echo "  Workers: $WORKERS"
echo "  Log Level: $LOG_LEVEL"

# 서버 실행
exec uvicorn src.server:app \
    --host "$HOST" \
    --port "$PORT" \
    --workers "$WORKERS" \
    --log-level "$LOG_LEVEL"
