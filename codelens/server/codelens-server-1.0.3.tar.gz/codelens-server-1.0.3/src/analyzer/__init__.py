# -*- coding: utf-8 -*-
"""CodeLens Analyzer Module

LLM-based code analysis functionality.

Modules:
- llm_client: OpenAI compatible API client
- chunk_analyzer: Chunk-by-chunk LLM analysis
- hierarchy: Hierarchical analysis integration
"""

from .llm_client import (
    LLMClient,
    LLMConfig,
    LLMResponse,
    create_client,
)

from .chunk_analyzer import (
    ChunkAnalyzer,
    ChunkAnalysisResult,
    AnalysisProgress,
    analyze_file_chunks,
)

from .hierarchy import (
    HierarchyMerger,
    HierarchyLevel,
    HierarchyResult,
    build_code_summary,
    print_hierarchy_progress,
)

__all__ = [
    # LLM Client
    'LLMClient',
    'LLMConfig',
    'LLMResponse',
    'create_client',
    # Chunk Analyzer
    'ChunkAnalyzer',
    'ChunkAnalysisResult',
    'AnalysisProgress',
    'analyze_file_chunks',
    # Hierarchy
    'HierarchyMerger',
    'HierarchyLevel',
    'HierarchyResult',
    'build_code_summary',
    'print_hierarchy_progress',
]
