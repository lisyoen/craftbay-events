"""계층적 분석 통합 모듈

청크 분석 결과를 계층적으로 통합하여 전체 코드 요약을 생성합니다.

계층 구조:
- Level 0: 개별 청크 분석 결과
- Level 1: 10개 청크씩 그룹화하여 통합
- Level 2: 5개 Level 1 결과씩 그룹화하여 통합
- Level 3: 최종 통합 (전체 파일/프로젝트 요약)
"""

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

from .llm_client import LLMClient, LLMConfig
from .chunk_analyzer import ChunkAnalysisResult


@dataclass
class HierarchyLevel:
    """계층 레벨 결과"""
    level: int
    group_index: int
    merged_count: int
    analysis: dict
    success: bool = True
    error: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "level": self.level,
            "group_index": self.group_index,
            "merged_count": self.merged_count,
            "success": self.success,
            "analysis": self.analysis,
            "error": self.error
        }


@dataclass
class HierarchyResult:
    """전체 계층 통합 결과"""
    levels: dict[int, list[HierarchyLevel]] = field(default_factory=dict)
    final_summary: Optional[dict] = None
    success: bool = True
    error: Optional[str] = None

    def add_level(self, level_result: HierarchyLevel) -> None:
        """레벨 결과 추가"""
        if level_result.level not in self.levels:
            self.levels[level_result.level] = []
        self.levels[level_result.level].append(level_result)

    def get_level(self, level: int) -> list[HierarchyLevel]:
        """특정 레벨의 모든 결과 반환"""
        return self.levels.get(level, [])

    def to_dict(self) -> dict:
        return {
            "levels": {
                level: [r.to_dict() for r in results]
                for level, results in self.levels.items()
            },
            "final_summary": self.final_summary,
            "success": self.success,
            "error": self.error
        }


class HierarchyMerger:
    """계층적 분석 통합 클래스"""

    # 각 레벨별 그룹 크기
    DEFAULT_GROUP_SIZES = {
        1: 10,  # Level 0 -> Level 1: 10개씩 그룹
        2: 5,   # Level 1 -> Level 2: 5개씩 그룹
        3: 10,  # Level 2 -> Level 3: 10개씩 그룹 (최종)
    }

    def __init__(
        self,
        client: Optional[LLMClient] = None,
        config: Optional[LLMConfig] = None,
        group_sizes: Optional[dict[int, int]] = None,
        output_dir: Optional[str | Path] = None
    ):
        """
        Args:
            client: LLM 클라이언트
            config: LLM 설정
            group_sizes: 레벨별 그룹 크기
            output_dir: 결과 저장 디렉토리
        """
        self.client = client or LLMClient(config)
        self.group_sizes = group_sizes or self.DEFAULT_GROUP_SIZES.copy()
        self.output_dir = Path(output_dir) if output_dir else None
        self._prompt_template: Optional[str] = None

    def load_prompt_template(self, template_path: Optional[str | Path] = None) -> str:
        """프롬프트 템플릿 로드"""
        if self._prompt_template and template_path is None:
            return self._prompt_template

        if template_path is None:
            module_dir = Path(__file__).parent
            template_path = module_dir / "prompts" / "hierarchy_merge.txt"

        with open(template_path, 'r', encoding='utf-8') as f:
            self._prompt_template = f.read()

        return self._prompt_template

    def merge_group(
        self,
        analyses: list[dict],
        level: int,
        group_index: int = 0
    ) -> HierarchyLevel:
        """그룹의 분석 결과를 통합

        Args:
            analyses: 통합할 분석 결과 목록
            level: 현재 레벨 (1, 2, 3)
            group_index: 그룹 인덱스

        Returns:
            HierarchyLevel 결과
        """
        template = self.load_prompt_template()

        # 분석 결과를 JSON 문자열로 변환
        analyses_text = json.dumps(analyses, ensure_ascii=False, indent=2)

        # 템플릿에 값 채우기
        prompt = template.replace("{{level}}", str(level))
        prompt = prompt.replace("{{count}}", str(len(analyses)))
        prompt = prompt.replace("{{analyses}}", analyses_text)

        try:
            response = self.client.complete(prompt, json_mode=True)

            if not response.success:
                return HierarchyLevel(
                    level=level,
                    group_index=group_index,
                    merged_count=len(analyses),
                    analysis={},
                    success=False,
                    error=response.error
                )

            parsed = response.parse_json()
            if parsed is None:
                return HierarchyLevel(
                    level=level,
                    group_index=group_index,
                    merged_count=len(analyses),
                    analysis={},
                    success=False,
                    error="Failed to parse JSON response"
                )

            return HierarchyLevel(
                level=level,
                group_index=group_index,
                merged_count=len(analyses),
                analysis=parsed,
                success=True
            )

        except Exception as e:
            return HierarchyLevel(
                level=level,
                group_index=group_index,
                merged_count=len(analyses),
                analysis={},
                success=False,
                error=str(e)
            )

    def merge_level(
        self,
        analyses: list[dict],
        target_level: int,
        progress_callback: Optional[Callable[[int, int, int], None]] = None
    ) -> list[HierarchyLevel]:
        """한 레벨의 분석 결과를 다음 레벨로 통합

        Args:
            analyses: 현재 레벨의 분석 결과들
            target_level: 목표 레벨 (1, 2, 3)
            progress_callback: 진행 콜백 (current, total, level)

        Returns:
            HierarchyLevel 결과 목록
        """
        if not analyses:
            return []

        group_size = self.group_sizes.get(target_level, 10)
        groups = self._split_into_groups(analyses, group_size)
        results = []

        for idx, group in enumerate(groups):
            if progress_callback:
                progress_callback(idx + 1, len(groups), target_level)

            result = self.merge_group(group, target_level, idx)
            results.append(result)

        return results

    def build_hierarchy(
        self,
        chunk_results: list[ChunkAnalysisResult],
        progress_callback: Optional[Callable[[int, int, int], None]] = None
    ) -> HierarchyResult:
        """청크 분석 결과로부터 전체 계층 구조 생성

        Args:
            chunk_results: 청크 분석 결과 목록
            progress_callback: 진행 콜백 (current, total, level)

        Returns:
            HierarchyResult 전체 계층 결과
        """
        result = HierarchyResult()

        # 성공한 분석만 사용
        level_0 = [
            r.analysis for r in chunk_results
            if r.success and r.analysis
        ]

        if not level_0:
            result.success = False
            result.error = "No successful chunk analyses to merge"
            return result

        current_analyses = level_0
        current_level = 0

        # 레벨 1, 2, 3까지 반복적으로 통합
        while len(current_analyses) > 1:
            target_level = current_level + 1

            if target_level > 3:
                # 3레벨 이상은 강제로 최종 통합
                level_results = [self.merge_group(current_analyses, target_level)]
            else:
                level_results = self.merge_level(
                    current_analyses,
                    target_level,
                    progress_callback
                )

            # 결과 저장
            for lr in level_results:
                result.add_level(lr)

            # 다음 레벨 입력 준비
            current_analyses = [
                lr.analysis for lr in level_results
                if lr.success and lr.analysis
            ]

            if not current_analyses:
                result.success = False
                result.error = f"All merges failed at level {target_level}"
                return result

            current_level = target_level

            # 하나만 남으면 종료
            if len(current_analyses) == 1:
                break

        # 최종 요약 설정
        if current_analyses:
            result.final_summary = current_analyses[0]

        return result

    def _split_into_groups(self, items: list, group_size: int) -> list[list]:
        """리스트를 지정된 크기의 그룹으로 분할"""
        groups = []
        for i in range(0, len(items), group_size):
            groups.append(items[i:i + group_size])
        return groups

    def save_result(self, result: HierarchyResult, file_path: str) -> None:
        """계층 결과 저장

        Args:
            result: 계층 결과
            file_path: 원본 파일 경로
        """
        if not self.output_dir:
            return

        self.output_dir.mkdir(parents=True, exist_ok=True)

        safe_name = Path(file_path).stem
        output_path = self.output_dir / f"hierarchy_{safe_name}.json"

        data = {
            "file_path": file_path,
            **result.to_dict()
        }

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)


def build_code_summary(
    chunk_results: list[ChunkAnalysisResult],
    config: Optional[LLMConfig] = None,
    output_dir: Optional[str | Path] = None,
    progress_callback: Optional[Callable[[int, int, int], None]] = None
) -> HierarchyResult:
    """청크 분석 결과로 코드 요약을 생성하는 편의 함수

    Args:
        chunk_results: 청크 분석 결과 목록
        config: LLM 설정
        output_dir: 결과 저장 디렉토리
        progress_callback: 진행 콜백

    Returns:
        HierarchyResult 객체
    """
    merger = HierarchyMerger(config=config, output_dir=output_dir)
    return merger.build_hierarchy(chunk_results, progress_callback)


def print_hierarchy_progress(current: int, total: int, level: int) -> None:
    """계층 통합 진행률 출력 (기본 콜백)"""
    print(f"  Level {level}: [{current}/{total}] groups merged")
