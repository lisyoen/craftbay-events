"""청크별 LLM 분석 모듈"""

import json
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

from ..parser.chunker import Chunk
from .llm_client import LLMClient, LLMConfig, LLMResponse


@dataclass
class ChunkAnalysisResult:
    """청크 분석 결과"""
    chunk_id: int
    success: bool
    analysis: dict
    error: Optional[str] = None
    raw_response: Optional[str] = None

    def to_dict(self) -> dict:
        """딕셔너리로 변환"""
        return {
            "chunk_id": self.chunk_id,
            "success": self.success,
            "analysis": self.analysis,
            "error": self.error
        }


@dataclass
class AnalysisProgress:
    """분석 진행 상황"""
    total: int
    completed: int = 0
    success: int = 0
    failed: int = 0

    @property
    def percent(self) -> float:
        if self.total == 0:
            return 100.0
        return (self.completed / self.total) * 100

    def update(self, success: bool) -> None:
        self.completed += 1
        if success:
            self.success += 1
        else:
            self.failed += 1


class ChunkAnalyzer:
    """청크별 LLM 분석 수행 클래스"""

    def __init__(
        self,
        client: Optional[LLMClient] = None,
        config: Optional[LLMConfig] = None,
        parallel_workers: int = 3,
        output_dir: Optional[str | Path] = None
    ):
        """
        Args:
            client: LLM 클라이언트 (None이면 새로 생성)
            config: LLM 설정 (client가 None일 때 사용)
            parallel_workers: 병렬 워커 수
            output_dir: 결과 저장 디렉토리
        """
        self.client = client or LLMClient(config)
        self.parallel_workers = parallel_workers
        self.output_dir = Path(output_dir) if output_dir else None
        self._prompt_template: Optional[str] = None

    def load_prompt_template(self, template_path: Optional[str | Path] = None) -> str:
        """프롬프트 템플릿 로드

        Args:
            template_path: 템플릿 파일 경로 (None이면 기본 경로 사용)

        Returns:
            템플릿 문자열
        """
        if self._prompt_template and template_path is None:
            return self._prompt_template

        if template_path is None:
            # 기본 경로: 이 모듈과 같은 디렉토리의 prompts/chunk_analysis.txt
            module_dir = Path(__file__).parent
            template_path = module_dir / "prompts" / "chunk_analysis.txt"

        with open(template_path, 'r', encoding='utf-8') as f:
            self._prompt_template = f.read()

        return self._prompt_template

    def analyze_chunk(
        self,
        chunk: Chunk,
        file_path: str = "unknown"
    ) -> ChunkAnalysisResult:
        """단일 청크 분석

        Args:
            chunk: 분석할 청크
            file_path: 파일 경로 (컨텍스트용)

        Returns:
            ChunkAnalysisResult 객체
        """
        template = self.load_prompt_template()

        context = {
            "chunk_id": str(chunk.chunk_id),
            "file_path": file_path,
            "start_line": str(chunk.start_line),
            "end_line": str(chunk.end_line),
        }

        try:
            response = self.client.analyze_code(
                code=chunk.source_code,
                prompt_template=template,
                context=context
            )

            if not response.success:
                return ChunkAnalysisResult(
                    chunk_id=chunk.chunk_id,
                    success=False,
                    analysis={},
                    error=response.error,
                    raw_response=response.content
                )

            parsed = response.parse_json()
            if parsed is None:
                return ChunkAnalysisResult(
                    chunk_id=chunk.chunk_id,
                    success=False,
                    analysis={},
                    error="Failed to parse JSON response",
                    raw_response=response.content
                )

            return ChunkAnalysisResult(
                chunk_id=chunk.chunk_id,
                success=True,
                analysis=parsed,
                raw_response=response.content
            )

        except Exception as e:
            return ChunkAnalysisResult(
                chunk_id=chunk.chunk_id,
                success=False,
                analysis={},
                error=str(e)
            )

    def analyze_chunks(
        self,
        chunks: list[Chunk],
        file_path: str = "unknown",
        progress_callback: Optional[Callable[[AnalysisProgress], None]] = None,
        save_results: bool = True
    ) -> list[ChunkAnalysisResult]:
        """여러 청크 병렬 분석

        Args:
            chunks: 분석할 청크 목록
            file_path: 파일 경로 (컨텍스트용)
            progress_callback: 진행 상황 콜백 함수
            save_results: 결과를 파일로 저장할지 여부

        Returns:
            ChunkAnalysisResult 목록
        """
        if not chunks:
            return []

        progress = AnalysisProgress(total=len(chunks))
        results: list[ChunkAnalysisResult] = []

        # 병렬 실행
        with ThreadPoolExecutor(max_workers=self.parallel_workers) as executor:
            future_to_chunk = {
                executor.submit(self.analyze_chunk, chunk, file_path): chunk
                for chunk in chunks
            }

            for future in as_completed(future_to_chunk):
                chunk = future_to_chunk[future]
                try:
                    result = future.result()
                except Exception as e:
                    result = ChunkAnalysisResult(
                        chunk_id=chunk.chunk_id,
                        success=False,
                        analysis={},
                        error=str(e)
                    )

                results.append(result)
                progress.update(result.success)

                if progress_callback:
                    progress_callback(progress)

        # chunk_id 순으로 정렬
        results.sort(key=lambda r: r.chunk_id)

        # 결과 저장
        if save_results and self.output_dir:
            self._save_results(results, file_path)

        return results

    def analyze_chunks_sequential(
        self,
        chunks: list[Chunk],
        file_path: str = "unknown",
        progress_callback: Optional[Callable[[AnalysisProgress], None]] = None
    ) -> list[ChunkAnalysisResult]:
        """청크를 순차적으로 분석 (디버깅/테스트용)

        Args:
            chunks: 분석할 청크 목록
            file_path: 파일 경로
            progress_callback: 진행 상황 콜백

        Returns:
            ChunkAnalysisResult 목록
        """
        if not chunks:
            return []

        progress = AnalysisProgress(total=len(chunks))
        results = []

        for chunk in chunks:
            result = self.analyze_chunk(chunk, file_path)
            results.append(result)
            progress.update(result.success)

            if progress_callback:
                progress_callback(progress)

        return results

    def _save_results(self, results: list[ChunkAnalysisResult], file_path: str) -> None:
        """분석 결과 저장

        Args:
            results: 분석 결과 목록
            file_path: 원본 파일 경로
        """
        if not self.output_dir:
            return

        self.output_dir.mkdir(parents=True, exist_ok=True)

        # 파일명 생성 (경로를 안전한 파일명으로 변환)
        safe_name = Path(file_path).stem
        output_path = self.output_dir / f"chunks_{safe_name}.json"

        data = {
            "file_path": file_path,
            "total_chunks": len(results),
            "success_count": sum(1 for r in results if r.success),
            "results": [r.to_dict() for r in results]
        }

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    @staticmethod
    def print_progress(progress: AnalysisProgress) -> None:
        """진행률 출력 (기본 콜백 함수)"""
        bar_width = 30
        filled = int(bar_width * progress.completed / progress.total)
        bar = '=' * filled + '-' * (bar_width - filled)
        status = f"[{bar}] {progress.completed}/{progress.total}"
        status += f" (OK:{progress.success}, FAIL:{progress.failed})"
        sys.stdout.write(f"\r{status}")
        sys.stdout.flush()
        if progress.completed == progress.total:
            sys.stdout.write('\n')


def analyze_file_chunks(
    chunks: list[Chunk],
    file_path: str,
    config: Optional[LLMConfig] = None,
    parallel_workers: int = 3,
    output_dir: Optional[str | Path] = None,
    show_progress: bool = True
) -> list[ChunkAnalysisResult]:
    """파일의 청크들을 분석하는 편의 함수

    Args:
        chunks: 분석할 청크 목록
        file_path: 파일 경로
        config: LLM 설정
        parallel_workers: 병렬 워커 수
        output_dir: 결과 저장 디렉토리
        show_progress: 진행률 표시 여부

    Returns:
        ChunkAnalysisResult 목록
    """
    analyzer = ChunkAnalyzer(
        config=config,
        parallel_workers=parallel_workers,
        output_dir=output_dir
    )

    callback = ChunkAnalyzer.print_progress if show_progress else None

    return analyzer.analyze_chunks(
        chunks=chunks,
        file_path=file_path,
        progress_callback=callback
    )
