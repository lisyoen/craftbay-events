"""OpenAI 호환 API 클라이언트 모듈"""

import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional
import urllib.request
import urllib.error


@dataclass
class LLMConfig:
    """LLM 설정"""
    base_url: str = "http://localhost:4000/v1"
    model: str = "Qwen/Qwen3-Coder-30B-A3B-Instruct"
    api_key: str = ""
    max_output_tokens: int = 4096
    temperature: float = 0.2
    timeout: int = 120
    retry_count: int = 2
    retry_delay: float = 1.0

    @classmethod
    def from_yaml(cls, config_path: str | Path) -> 'LLMConfig':
        """YAML 파일에서 설정 로드"""
        import yaml
        with open(config_path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)

        llm_config = data.get('llm', {})
        return cls(
            base_url=llm_config.get('base_url', cls.base_url),
            model=llm_config.get('model', cls.model),
            api_key=llm_config.get('api_key', cls.api_key),
            max_output_tokens=llm_config.get('max_output_tokens', cls.max_output_tokens),
            temperature=llm_config.get('temperature', cls.temperature),
            timeout=llm_config.get('timeout', cls.timeout),
            retry_count=llm_config.get('retry_count', cls.retry_count),
            retry_delay=llm_config.get('retry_delay', cls.retry_delay),
        )


@dataclass
class LLMResponse:
    """LLM 응답 결과"""
    content: str
    model: str
    usage: dict
    raw_response: dict
    success: bool = True
    error: Optional[str] = None

    def to_json(self) -> dict:
        """JSON dict로 변환"""
        parsed = self.parse_json()
        if parsed:
            return parsed
        return {"raw_content": self.content}

    def parse_json(self) -> Optional[dict]:
        """응답 내용에서 JSON 추출 시도"""
        content = self.content.strip()

        # 코드 블록 제거 (```json ... ```)
        if content.startswith('```'):
            lines = content.split('\n')
            # 첫 줄의 ```json 또는 ``` 제거
            if lines[0].startswith('```'):
                lines = lines[1:]
            # 마지막 줄의 ``` 제거
            if lines and lines[-1].strip() == '```':
                lines = lines[:-1]
            content = '\n'.join(lines)

        try:
            return json.loads(content)
        except json.JSONDecodeError:
            # JSON 부분 추출 시도
            start_idx = content.find('{')
            end_idx = content.rfind('}')
            if start_idx != -1 and end_idx != -1:
                try:
                    return json.loads(content[start_idx:end_idx + 1])
                except json.JSONDecodeError:
                    pass
            return None


class LLMClient:
    """OpenAI 호환 API 클라이언트"""

    def __init__(self, config: Optional[LLMConfig] = None):
        """
        Args:
            config: LLM 설정 (None이면 기본값 사용)
        """
        self.config = config or LLMConfig()
        self._endpoint = f"{self.config.base_url.rstrip('/')}/chat/completions"

    def chat(
        self,
        messages: list[dict],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        json_mode: bool = False
    ) -> LLMResponse:
        """채팅 완성 요청

        Args:
            messages: 메시지 목록 [{"role": "user", "content": "..."}]
            temperature: 온도 (None이면 설정값 사용)
            max_tokens: 최대 토큰 (None이면 설정값 사용)
            json_mode: JSON 모드 활성화 여부

        Returns:
            LLMResponse 객체
        """
        payload = {
            "model": self.config.model,
            "messages": messages,
            "temperature": temperature if temperature is not None else self.config.temperature,
            "max_tokens": max_tokens if max_tokens is not None else self.config.max_output_tokens,
        }

        if json_mode:
            payload["response_format"] = {"type": "json_object"}

        last_error = None
        for attempt in range(self.config.retry_count + 1):
            try:
                response = self._send_request(payload)
                return self._parse_response(response)
            except Exception as e:
                last_error = str(e)
                if attempt < self.config.retry_count:
                    time.sleep(self.config.retry_delay * (attempt + 1))

        return LLMResponse(
            content="",
            model=self.config.model,
            usage={},
            raw_response={},
            success=False,
            error=f"Failed after {self.config.retry_count + 1} attempts: {last_error}"
        )

    def complete(self, prompt: str, **kwargs) -> LLMResponse:
        """단일 프롬프트로 요청 (편의 메서드)

        Args:
            prompt: 사용자 프롬프트
            **kwargs: chat() 메서드에 전달할 추가 인자

        Returns:
            LLMResponse 객체
        """
        messages = [{"role": "user", "content": prompt}]
        return self.chat(messages, **kwargs)

    def analyze_code(
        self,
        code: str,
        prompt_template: str,
        context: Optional[dict] = None
    ) -> LLMResponse:
        """코드 분석 요청

        Args:
            code: 분석할 코드
            prompt_template: 프롬프트 템플릿 ({{code}}, {{context}} 플레이스홀더 지원)
            context: 추가 컨텍스트 딕셔너리

        Returns:
            LLMResponse 객체
        """
        prompt = prompt_template.replace("{{code}}", code)

        if context:
            for key, value in context.items():
                placeholder = f"{{{{{key}}}}}"
                if isinstance(value, dict):
                    value = json.dumps(value, ensure_ascii=False, indent=2)
                prompt = prompt.replace(placeholder, str(value))

        return self.complete(prompt, json_mode=True)

    def _send_request(self, payload: dict) -> dict:
        """HTTP 요청 전송"""
        headers = {
            "Content-Type": "application/json",
        }

        if self.config.api_key:
            headers["Authorization"] = f"Bearer {self.config.api_key}"

        data = json.dumps(payload).encode('utf-8')
        request = urllib.request.Request(
            self._endpoint,
            data=data,
            headers=headers,
            method='POST'
        )

        try:
            with urllib.request.urlopen(request, timeout=self.config.timeout) as response:
                return json.loads(response.read().decode('utf-8'))
        except urllib.error.HTTPError as e:
            error_body = e.read().decode('utf-8') if e.fp else ''
            raise RuntimeError(f"HTTP {e.code}: {error_body}")
        except urllib.error.URLError as e:
            raise RuntimeError(f"Connection error: {e.reason}")

    def _parse_response(self, response: dict) -> LLMResponse:
        """API 응답 파싱"""
        choices = response.get('choices', [])
        if not choices:
            return LLMResponse(
                content="",
                model=response.get('model', ''),
                usage=response.get('usage', {}),
                raw_response=response,
                success=False,
                error="No choices in response"
            )

        message = choices[0].get('message', {})
        content = message.get('content', '')

        return LLMResponse(
            content=content,
            model=response.get('model', self.config.model),
            usage=response.get('usage', {}),
            raw_response=response,
            success=True
        )

    def test_connection(self) -> tuple[bool, str]:
        """연결 테스트

        Returns:
            (성공 여부, 메시지) 튜플
        """
        try:
            response = self.complete("Say 'OK' if you can read this.")
            if response.success:
                return True, f"Connected to {self.config.model}"
            return False, f"Request failed: {response.error}"
        except Exception as e:
            return False, f"Connection error: {e}"


def create_client(config_path: Optional[str | Path] = None) -> LLMClient:
    """LLM 클라이언트 생성 편의 함수

    Args:
        config_path: 설정 파일 경로 (None이면 기본 설정 사용)

    Returns:
        LLMClient 인스턴스
    """
    if config_path:
        config = LLMConfig.from_yaml(config_path)
    else:
        config = LLMConfig()
    return LLMClient(config)
