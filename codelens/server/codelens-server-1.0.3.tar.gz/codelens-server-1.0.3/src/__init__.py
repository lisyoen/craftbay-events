# CodeLens - JavaScript Code Analysis Tool
"""CodeLens: HTML/JS 추출 및 AST 기반 청크 분리 모듈"""

__version__ = "0.1.0"
