"""함수 호출 관계 및 의존성 분석 모듈"""

import json
from dataclasses import dataclass, field
from typing import Any, Optional
from pathlib import Path
from .ast_parser import ASTNode, JSASTParser


@dataclass
class CallInfo:
    """함수 호출 정보"""
    caller: str
    callee: str
    line: int
    call_type: str = "call"  # call, new, method


@dataclass
class ImportInfo:
    """import 정보"""
    source: str  # 모듈 경로
    imported_names: list[str] = field(default_factory=list)
    is_default: bool = False
    is_namespace: bool = False
    line: int = 0


@dataclass
class ExportInfo:
    """export 정보"""
    name: str
    export_type: str  # default, named, all
    line: int = 0


@dataclass
class DependencyGraph:
    """의존성 그래프"""
    nodes: list[str]  # 함수/클래스 이름
    edges: list[tuple[str, str]]  # (caller, callee) 관계
    imports: list[ImportInfo]
    exports: list[ExportInfo]
    calls: list[CallInfo]

    def to_dict(self) -> dict:
        """딕셔너리로 변환"""
        return {
            "nodes": self.nodes,
            "edges": self.edges,
            "imports": [
                {
                    "source": i.source,
                    "imported_names": i.imported_names,
                    "is_default": i.is_default,
                    "is_namespace": i.is_namespace,
                    "line": i.line,
                }
                for i in self.imports
            ],
            "exports": [
                {
                    "name": e.name,
                    "export_type": e.export_type,
                    "line": e.line,
                }
                for e in self.exports
            ],
            "calls": [
                {
                    "caller": c.caller,
                    "callee": c.callee,
                    "line": c.line,
                    "call_type": c.call_type,
                }
                for c in self.calls
            ],
        }

    def to_json(self, indent: int = 2) -> str:
        """JSON 문자열로 변환"""
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)

    def save_json(self, filepath: str | Path) -> None:
        """JSON 파일로 저장"""
        path = Path(filepath)
        path.write_text(self.to_json(), encoding='utf-8')


class DependencyAnalyzer:
    """의존성 분석 클래스

    - 함수 호출 관계 추출
    - import/export 분석
    - 의존성 그래프 생성
    """

    def __init__(self, source_code: str):
        """
        Args:
            source_code: JavaScript 소스 코드
        """
        self.source_code = source_code
        self.parser = JSASTParser(source_code)
        self._graph: Optional[DependencyGraph] = None
        self._analyzed = False

    def analyze(self) -> DependencyGraph:
        """소스 코드 분석 후 의존성 그래프 반환"""
        if self._analyzed:
            return self._graph

        ast = self.parser.parse()

        imports = self._extract_imports(ast)
        exports = self._extract_exports(ast)
        calls = self._extract_calls(ast)
        nodes = self._extract_nodes(ast)
        edges = self._build_edges(calls)

        self._graph = DependencyGraph(
            nodes=nodes,
            edges=edges,
            imports=imports,
            exports=exports,
            calls=calls,
        )
        self._analyzed = True
        return self._graph

    def _extract_imports(self, ast: dict) -> list[ImportInfo]:
        """import 선언 추출"""
        imports = []
        body = ast.get('body', [])

        for node in body:
            if node.get('type') != 'ImportDeclaration':
                continue

            source = node.get('source', {}).get('value', '')
            specifiers = node.get('specifiers', [])
            loc = node.get('loc', {}).get('start', {})
            line = loc.get('line', 0)

            imported_names = []
            is_default = False
            is_namespace = False

            for spec in specifiers:
                spec_type = spec.get('type')
                if spec_type == 'ImportDefaultSpecifier':
                    is_default = True
                    local = spec.get('local', {})
                    imported_names.append(local.get('name', ''))
                elif spec_type == 'ImportNamespaceSpecifier':
                    is_namespace = True
                    local = spec.get('local', {})
                    imported_names.append(f"* as {local.get('name', '')}")
                elif spec_type == 'ImportSpecifier':
                    imported = spec.get('imported', {})
                    local = spec.get('local', {})
                    imp_name = imported.get('name', '')
                    loc_name = local.get('name', '')
                    if imp_name == loc_name:
                        imported_names.append(imp_name)
                    else:
                        imported_names.append(f"{imp_name} as {loc_name}")

            imports.append(ImportInfo(
                source=source,
                imported_names=imported_names,
                is_default=is_default,
                is_namespace=is_namespace,
                line=line,
            ))

        return imports

    def _extract_exports(self, ast: dict) -> list[ExportInfo]:
        """export 선언 추출"""
        exports = []
        body = ast.get('body', [])

        for node in body:
            node_type = node.get('type')
            loc = node.get('loc', {}).get('start', {})
            line = loc.get('line', 0)

            if node_type == 'ExportDefaultDeclaration':
                decl = node.get('declaration', {})
                name = self._get_declaration_name(decl) or 'default'
                exports.append(ExportInfo(
                    name=name,
                    export_type='default',
                    line=line,
                ))

            elif node_type == 'ExportNamedDeclaration':
                decl = node.get('declaration')
                specifiers = node.get('specifiers', [])

                if decl:
                    name = self._get_declaration_name(decl)
                    if name:
                        exports.append(ExportInfo(
                            name=name,
                            export_type='named',
                            line=line,
                        ))

                for spec in specifiers:
                    exported = spec.get('exported', {})
                    exports.append(ExportInfo(
                        name=exported.get('name', ''),
                        export_type='named',
                        line=line,
                    ))

            elif node_type == 'ExportAllDeclaration':
                source = node.get('source', {}).get('value', '')
                exports.append(ExportInfo(
                    name=f"* from {source}",
                    export_type='all',
                    line=line,
                ))

        return exports

    def _get_declaration_name(self, decl: dict) -> Optional[str]:
        """선언에서 이름 추출"""
        if not decl:
            return None

        decl_type = decl.get('type')

        if decl_type in ('FunctionDeclaration', 'ClassDeclaration'):
            id_node = decl.get('id', {})
            return id_node.get('name') if id_node else None

        elif decl_type == 'VariableDeclaration':
            declarations = decl.get('declarations', [])
            if declarations:
                first = declarations[0]
                id_node = first.get('id', {})
                return id_node.get('name') if id_node else None

        return None

    def _extract_calls(self, ast: dict) -> list[CallInfo]:
        """함수 호출 추출"""
        calls = []
        self._walk_calls(ast, calls, current_scope=None)
        return calls

    def _walk_calls(
        self,
        node: Any,
        calls: list[CallInfo],
        current_scope: Optional[str]
    ) -> None:
        """AST를 순회하며 함수 호출 수집"""
        if not isinstance(node, dict):
            return

        node_type = node.get('type')

        # 새 스코프 진입
        new_scope = current_scope
        if node_type == 'FunctionDeclaration':
            id_node = node.get('id', {})
            new_scope = id_node.get('name') if id_node else current_scope
        elif node_type == 'FunctionExpression':
            id_node = node.get('id', {})
            new_scope = id_node.get('name') if id_node else current_scope
        elif node_type == 'ArrowFunctionExpression':
            pass  # 화살표 함수는 이름 없음
        elif node_type == 'ClassDeclaration':
            id_node = node.get('id', {})
            new_scope = id_node.get('name') if id_node else current_scope
        elif node_type == 'MethodDefinition':
            key = node.get('key', {})
            method_name = key.get('name', '')
            if current_scope and method_name:
                new_scope = f"{current_scope}.{method_name}"
            elif method_name:
                new_scope = method_name

        # 함수 호출 감지
        if node_type == 'CallExpression':
            callee = node.get('callee', {})
            callee_name = self._get_callee_name(callee)
            loc = node.get('loc', {}).get('start', {})
            line = loc.get('line', 0)

            if callee_name:
                calls.append(CallInfo(
                    caller=new_scope or '<global>',
                    callee=callee_name,
                    line=line,
                    call_type='call',
                ))

        elif node_type == 'NewExpression':
            callee = node.get('callee', {})
            callee_name = self._get_callee_name(callee)
            loc = node.get('loc', {}).get('start', {})
            line = loc.get('line', 0)

            if callee_name:
                calls.append(CallInfo(
                    caller=new_scope or '<global>',
                    callee=callee_name,
                    line=line,
                    call_type='new',
                ))

        # 자식 노드 순회
        for key, value in node.items():
            if key in ('loc', 'range'):
                continue
            if isinstance(value, dict):
                self._walk_calls(value, calls, new_scope)
            elif isinstance(value, list):
                for item in value:
                    self._walk_calls(item, calls, new_scope)

    def _get_callee_name(self, callee: dict) -> Optional[str]:
        """호출 대상 이름 추출"""
        if not isinstance(callee, dict):
            return None

        callee_type = callee.get('type')

        if callee_type == 'Identifier':
            return callee.get('name')

        elif callee_type == 'MemberExpression':
            obj = callee.get('object', {})
            prop = callee.get('property', {})

            obj_name = self._get_callee_name(obj)
            prop_name = prop.get('name') if prop.get('type') == 'Identifier' else None

            if obj_name and prop_name:
                return f"{obj_name}.{prop_name}"
            elif prop_name:
                return prop_name

        return None

    def _extract_nodes(self, ast: dict) -> list[str]:
        """그래프 노드(함수/클래스 이름) 추출"""
        nodes = set()
        body = ast.get('body', [])

        for node in body:
            node_type = node.get('type')

            if node_type == 'FunctionDeclaration':
                id_node = node.get('id', {})
                if id_node:
                    nodes.add(id_node.get('name', ''))

            elif node_type == 'ClassDeclaration':
                id_node = node.get('id', {})
                if id_node:
                    nodes.add(id_node.get('name', ''))

            elif node_type == 'VariableDeclaration':
                for decl in node.get('declarations', []):
                    init = decl.get('init', {})
                    if init and init.get('type') in ('FunctionExpression', 'ArrowFunctionExpression'):
                        id_node = decl.get('id', {})
                        if id_node:
                            nodes.add(id_node.get('name', ''))

        return sorted(nodes)

    def _build_edges(self, calls: list[CallInfo]) -> list[tuple[str, str]]:
        """호출 정보에서 엣지 목록 생성"""
        edges = set()
        for call in calls:
            if call.caller and call.callee:
                edges.add((call.caller, call.callee))
        return sorted(edges)

    @classmethod
    def from_file(cls, filepath: str | Path) -> 'DependencyAnalyzer':
        """파일에서 JS를 읽어 인스턴스 생성"""
        path = Path(filepath)
        content = path.read_text(encoding='utf-8')
        return cls(content)


def analyze_dependencies(source_code: str) -> DependencyGraph:
    """JavaScript 코드의 의존성을 분석하는 편의 함수

    Args:
        source_code: JavaScript 소스 코드

    Returns:
        DependencyGraph 객체
    """
    analyzer = DependencyAnalyzer(source_code)
    return analyzer.analyze()


def analyze_file_dependencies(filepath: str | Path) -> DependencyGraph:
    """JavaScript 파일의 의존성을 분석하는 편의 함수

    Args:
        filepath: JavaScript 파일 경로

    Returns:
        DependencyGraph 객체
    """
    analyzer = DependencyAnalyzer.from_file(filepath)
    return analyzer.analyze()
