"""AST 노드를 청크로 분리하는 모듈"""

from dataclasses import dataclass, field
from typing import Optional
from .ast_parser import ASTNode, JSASTParser


@dataclass
class Chunk:
    """코드 청크 데이터 클래스"""
    chunk_id: int
    nodes: list[ASTNode]
    start_line: int
    end_line: int
    size_bytes: int
    source_code: str
    description: str = ""

    @property
    def line_count(self) -> int:
        return self.end_line - self.start_line + 1

    @property
    def node_count(self) -> int:
        return len(self.nodes)

    @property
    def size_kb(self) -> float:
        return self.size_bytes / 1024


class ASTChunker:
    """AST 노드를 청크로 분리하는 클래스

    기획서 기준:
    - 목표 크기: 40KB (설정 가능)
    - 작은 노드는 병합, 큰 노드는 분할
    """

    def __init__(
        self,
        target_size_kb: int = 40,
        max_size_kb: int = 60,
        min_size_kb: int = 5
    ):
        """
        Args:
            target_size_kb: 목표 청크 크기 (KB)
            max_size_kb: 최대 청크 크기 (KB)
            min_size_kb: 최소 청크 크기 (KB)
        """
        self.target_size = target_size_kb * 1024
        self.max_size = max_size_kb * 1024
        self.min_size = min_size_kb * 1024

    def chunk_from_parser(self, parser: JSASTParser) -> list[Chunk]:
        """파서에서 노드를 가져와 청크로 분리

        Args:
            parser: JSASTParser 인스턴스

        Returns:
            Chunk 목록
        """
        nodes = parser.get_top_level_nodes()
        return self.chunk_nodes(nodes)

    def chunk_nodes(self, nodes: list[ASTNode]) -> list[Chunk]:
        """AST 노드 목록을 청크로 분리

        Args:
            nodes: ASTNode 목록

        Returns:
            Chunk 목록
        """
        if not nodes:
            return []

        chunks = []
        current_nodes = []
        current_size = 0
        chunk_id = 1

        for node in nodes:
            node_size = node.size_bytes

            # 노드 하나가 max_size를 초과하면 분할
            if node_size > self.max_size:
                # 현재 누적된 노드가 있으면 먼저 청크로 저장
                if current_nodes:
                    chunks.append(self._create_chunk(chunk_id, current_nodes))
                    chunk_id += 1
                    current_nodes = []
                    current_size = 0

                # 큰 노드는 별도로 분할
                sub_chunks = self._split_large_node(node, chunk_id)
                chunks.extend(sub_chunks)
                chunk_id += len(sub_chunks)
                continue

            # 현재 청크에 추가 시 max_size 초과하면 새 청크 시작
            if current_size + node_size > self.max_size and current_nodes:
                chunks.append(self._create_chunk(chunk_id, current_nodes))
                chunk_id += 1
                current_nodes = []
                current_size = 0

            current_nodes.append(node)
            current_size += node_size

            # target_size에 도달하면 청크 완료
            if current_size >= self.target_size:
                chunks.append(self._create_chunk(chunk_id, current_nodes))
                chunk_id += 1
                current_nodes = []
                current_size = 0

        # 남은 노드 처리
        if current_nodes:
            # min_size 미만이면 이전 청크에 병합 시도
            if current_size < self.min_size and chunks:
                last_chunk = chunks[-1]
                if last_chunk.size_bytes + current_size <= self.max_size:
                    # 이전 청크에 병합
                    merged_nodes = last_chunk.nodes + current_nodes
                    chunks[-1] = self._create_chunk(last_chunk.chunk_id, merged_nodes)
                else:
                    chunks.append(self._create_chunk(chunk_id, current_nodes))
            else:
                chunks.append(self._create_chunk(chunk_id, current_nodes))

        return chunks

    def _create_chunk(self, chunk_id: int, nodes: list[ASTNode]) -> Chunk:
        """노드 목록에서 Chunk 생성"""
        if not nodes:
            return Chunk(
                chunk_id=chunk_id,
                nodes=[],
                start_line=0,
                end_line=0,
                size_bytes=0,
                source_code=""
            )

        start_line = min(n.start_line for n in nodes)
        end_line = max(n.end_line for n in nodes)
        source_code = '\n\n'.join(n.source_code for n in nodes)
        size_bytes = len(source_code.encode('utf-8'))

        # 설명 생성
        node_types = {}
        for n in nodes:
            node_types[n.node_type] = node_types.get(n.node_type, 0) + 1
        desc_parts = [f"{t}:{c}" for t, c in node_types.items()]
        description = f"Lines {start_line}-{end_line}, {', '.join(desc_parts)}"

        return Chunk(
            chunk_id=chunk_id,
            nodes=nodes,
            start_line=start_line,
            end_line=end_line,
            size_bytes=size_bytes,
            source_code=source_code,
            description=description
        )

    def _split_large_node(self, node: ASTNode, start_id: int) -> list[Chunk]:
        """큰 노드를 라인 기준으로 분할

        Args:
            node: 분할할 노드
            start_id: 시작 청크 ID

        Returns:
            분할된 Chunk 목록
        """
        lines = node.source_code.split('\n')
        total_lines = len(lines)

        if total_lines == 0:
            return []

        # 라인당 평균 크기로 목표 라인 수 계산
        avg_line_size = node.size_bytes / total_lines
        target_lines = int(self.target_size / avg_line_size)
        target_lines = max(10, target_lines)  # 최소 10줄

        chunks = []
        chunk_id = start_id
        i = 0

        while i < total_lines:
            end_i = min(i + target_lines, total_lines)
            chunk_lines = lines[i:end_i]
            chunk_source = '\n'.join(chunk_lines)

            chunk = Chunk(
                chunk_id=chunk_id,
                nodes=[node],  # 원본 노드 참조
                start_line=node.start_line + i,
                end_line=node.start_line + end_i - 1,
                size_bytes=len(chunk_source.encode('utf-8')),
                source_code=chunk_source,
                description=f"Split from {node.node_type}: {node.name or 'anonymous'} (part {chunk_id - start_id + 1})"
            )
            chunks.append(chunk)
            chunk_id += 1
            i = end_i

        return chunks

    def get_summary(self, chunks: list[Chunk]) -> dict:
        """청크들의 요약 정보"""
        if not chunks:
            return {
                "total_chunks": 0,
                "total_size_kb": 0,
                "avg_size_kb": 0,
                "min_size_kb": 0,
                "max_size_kb": 0,
            }

        sizes = [c.size_bytes for c in chunks]
        total_size = sum(sizes)

        return {
            "total_chunks": len(chunks),
            "total_size_kb": round(total_size / 1024, 2),
            "avg_size_kb": round((total_size / len(chunks)) / 1024, 2),
            "min_size_kb": round(min(sizes) / 1024, 2),
            "max_size_kb": round(max(sizes) / 1024, 2),
            "total_nodes": sum(c.node_count for c in chunks),
            "total_lines": sum(c.line_count for c in chunks),
        }


def chunk_js_code(source_code: str, target_size_kb: int = 40) -> list[Chunk]:
    """JavaScript 코드를 청크로 분리하는 편의 함수

    Args:
        source_code: JavaScript 소스 코드
        target_size_kb: 목표 청크 크기 (KB)

    Returns:
        Chunk 목록
    """
    parser = JSASTParser(source_code)
    chunker = ASTChunker(target_size_kb=target_size_kb)
    return chunker.chunk_from_parser(parser)


def chunk_js_file(filepath: str, target_size_kb: int = 40) -> list[Chunk]:
    """JavaScript 파일을 청크로 분리하는 편의 함수

    Args:
        filepath: JavaScript 파일 경로
        target_size_kb: 목표 청크 크기 (KB)

    Returns:
        Chunk 목록
    """
    parser = JSASTParser.from_file(filepath)
    chunker = ASTChunker(target_size_kb=target_size_kb)
    return chunker.chunk_from_parser(parser)
