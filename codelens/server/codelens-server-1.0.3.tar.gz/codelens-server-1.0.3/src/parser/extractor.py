"""HTML에서 JavaScript 코드를 추출하는 모듈"""

from dataclasses import dataclass
from pathlib import Path
from typing import Optional
from bs4 import BeautifulSoup


@dataclass
class ScriptInfo:
    """추출된 스크립트 정보"""
    content: str
    source_type: str  # 'inline' | 'external'
    src: Optional[str] = None
    line_number: Optional[int] = None
    script_type: Optional[str] = None  # type 속성 (module, text/javascript 등)


class HTMLScriptExtractor:
    """HTML 문서에서 <script> 태그를 추출하는 클래스"""

    def __init__(self, html_content: str):
        """
        Args:
            html_content: HTML 문서 문자열
        """
        self.html_content = html_content
        self.soup = BeautifulSoup(html_content, 'html.parser')
        self._scripts: list[ScriptInfo] = []
        self._parsed = False

    def parse(self) -> list[ScriptInfo]:
        """HTML에서 모든 <script> 태그를 파싱하여 ScriptInfo 목록 반환"""
        if self._parsed:
            return self._scripts

        self._scripts = []
        lines = self.html_content.split('\n')

        for script_tag in self.soup.find_all('script'):
            src = script_tag.get('src')
            script_type = script_tag.get('type')

            # 라인 번호 계산 (근사치)
            line_number = self._find_line_number(str(script_tag), lines)

            if src:
                # 외부 스크립트 참조
                self._scripts.append(ScriptInfo(
                    content='',
                    source_type='external',
                    src=src,
                    line_number=line_number,
                    script_type=script_type
                ))
            else:
                # 인라인 스크립트
                content = script_tag.string or ''
                if content.strip():
                    self._scripts.append(ScriptInfo(
                        content=content,
                        source_type='inline',
                        src=None,
                        line_number=line_number,
                        script_type=script_type
                    ))

        self._parsed = True
        return self._scripts

    def _find_line_number(self, tag_str: str, lines: list[str]) -> Optional[int]:
        """태그의 시작 라인 번호를 찾음 (1-based)"""
        # 태그의 첫 부분으로 검색
        tag_start = tag_str[:50] if len(tag_str) > 50 else tag_str
        for i, line in enumerate(lines, 1):
            if '<script' in line:
                return i
        return None

    def get_inline_scripts(self) -> list[ScriptInfo]:
        """인라인 스크립트만 반환"""
        if not self._parsed:
            self.parse()
        return [s for s in self._scripts if s.source_type == 'inline']

    def get_external_scripts(self) -> list[ScriptInfo]:
        """외부 스크립트 참조만 반환"""
        if not self._parsed:
            self.parse()
        return [s for s in self._scripts if s.source_type == 'external']

    def get_all_js_content(self) -> str:
        """모든 인라인 스크립트 내용을 하나의 문자열로 결합"""
        if not self._parsed:
            self.parse()
        return '\n\n'.join(s.content for s in self._scripts if s.content)

    @classmethod
    def from_file(cls, filepath: str | Path) -> 'HTMLScriptExtractor':
        """파일에서 HTML을 읽어 인스턴스 생성"""
        path = Path(filepath)
        with open(path, 'r', encoding='utf-8') as f:
            return cls(f.read())


def extract_scripts_from_html(html_content: str) -> list[ScriptInfo]:
    """HTML에서 스크립트를 추출하는 편의 함수"""
    extractor = HTMLScriptExtractor(html_content)
    return extractor.parse()


def extract_scripts_from_file(filepath: str | Path) -> list[ScriptInfo]:
    """파일에서 HTML을 읽고 스크립트를 추출하는 편의 함수"""
    extractor = HTMLScriptExtractor.from_file(filepath)
    return extractor.parse()
