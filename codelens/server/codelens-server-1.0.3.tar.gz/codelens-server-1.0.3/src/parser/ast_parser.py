"""JavaScript AST 파싱 모듈 - esprima 기반"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional
import esprima


@dataclass
class ASTNode:
    """AST 노드 정보를 담는 데이터 클래스"""
    node_type: str
    name: Optional[str]
    start_line: int
    end_line: int
    start_col: int = 0
    end_col: int = 0
    raw_node: dict = field(default_factory=dict)
    source_code: str = ''
    children: list['ASTNode'] = field(default_factory=list)

    @property
    def line_count(self) -> int:
        return self.end_line - self.start_line + 1

    @property
    def size_bytes(self) -> int:
        return len(self.source_code.encode('utf-8'))


class JSASTParser:
    """JavaScript AST 파서 클래스"""

    # 최상위 레벨에서 분리할 노드 타입
    TOP_LEVEL_TYPES = {
        'FunctionDeclaration',
        'ClassDeclaration',
        'VariableDeclaration',
        'ExportDefaultDeclaration',
        'ExportNamedDeclaration',
        'ImportDeclaration',
    }

    def __init__(self, source_code: str):
        """
        Args:
            source_code: JavaScript 소스 코드
        """
        self.source_code = source_code
        self.source_lines = source_code.split('\n')
        self._ast: Optional[dict] = None
        self._nodes: list[ASTNode] = []
        self._parsed = False

    def parse(self) -> dict:
        """소스 코드를 파싱하여 AST 반환"""
        if self._ast is not None:
            return self._ast

        try:
            self._ast = esprima.parseScript(
                self.source_code,
                loc=True,
                range=True,
                tokens=False,
                comment=True
            ).toDict()
        except esprima.Error:
            # ES Module 문법 시도
            self._ast = esprima.parseModule(
                self.source_code,
                loc=True,
                range=True,
                tokens=False,
                comment=True
            ).toDict()

        return self._ast

    def get_top_level_nodes(self) -> list[ASTNode]:
        """최상위 레벨 노드(함수, 클래스, 변수 선언 등)를 추출"""
        if self._parsed:
            return self._nodes

        ast = self.parse()
        body = ast.get('body', [])

        self._nodes = []
        for node in body:
            ast_node = self._convert_to_ast_node(node)
            if ast_node:
                self._nodes.append(ast_node)

        self._parsed = True
        return self._nodes

    def _convert_to_ast_node(self, node: dict) -> Optional[ASTNode]:
        """esprima 노드를 ASTNode로 변환"""
        if not isinstance(node, dict) or 'type' not in node:
            return None

        node_type = node['type']
        loc = node.get('loc', {})
        start = loc.get('start', {})
        end = loc.get('end', {})

        start_line = start.get('line', 1)
        end_line = end.get('line', 1)
        start_col = start.get('column', 0)
        end_col = end.get('column', 0)

        # 노드 이름 추출
        name = self._extract_name(node)

        # 소스 코드 추출
        source_code = self._extract_source(start_line, end_line)

        return ASTNode(
            node_type=node_type,
            name=name,
            start_line=start_line,
            end_line=end_line,
            start_col=start_col,
            end_col=end_col,
            raw_node=node,
            source_code=source_code
        )

    def _extract_name(self, node: dict) -> Optional[str]:
        """노드에서 이름(식별자) 추출"""
        node_type = node.get('type')

        if node_type == 'FunctionDeclaration':
            id_node = node.get('id', {})
            return id_node.get('name') if id_node else None

        elif node_type == 'ClassDeclaration':
            id_node = node.get('id', {})
            return id_node.get('name') if id_node else None

        elif node_type == 'VariableDeclaration':
            declarations = node.get('declarations', [])
            if declarations:
                names = []
                for decl in declarations:
                    id_node = decl.get('id', {})
                    if id_node.get('type') == 'Identifier':
                        names.append(id_node.get('name', ''))
                return ', '.join(names) if names else None

        elif node_type in ('ExportDefaultDeclaration', 'ExportNamedDeclaration'):
            decl = node.get('declaration')
            if decl:
                return self._extract_name(decl)

        elif node_type == 'ImportDeclaration':
            source = node.get('source', {})
            return source.get('value')

        return None

    def _extract_source(self, start_line: int, end_line: int) -> str:
        """라인 번호 범위로 소스 코드 추출"""
        if start_line < 1:
            start_line = 1
        if end_line > len(self.source_lines):
            end_line = len(self.source_lines)

        return '\n'.join(self.source_lines[start_line - 1:end_line])

    def get_functions(self) -> list[ASTNode]:
        """함수 선언만 필터링"""
        nodes = self.get_top_level_nodes()
        return [n for n in nodes if n.node_type == 'FunctionDeclaration']

    def get_classes(self) -> list[ASTNode]:
        """클래스 선언만 필터링"""
        nodes = self.get_top_level_nodes()
        return [n for n in nodes if n.node_type == 'ClassDeclaration']

    def get_variables(self) -> list[ASTNode]:
        """변수 선언만 필터링"""
        nodes = self.get_top_level_nodes()
        return [n for n in nodes if n.node_type == 'VariableDeclaration']

    def get_imports(self) -> list[ASTNode]:
        """import 선언만 필터링"""
        nodes = self.get_top_level_nodes()
        return [n for n in nodes if n.node_type == 'ImportDeclaration']

    def get_exports(self) -> list[ASTNode]:
        """export 선언만 필터링"""
        nodes = self.get_top_level_nodes()
        return [n for n in nodes if n.node_type in (
            'ExportDefaultDeclaration',
            'ExportNamedDeclaration'
        )]

    def get_line_mapping(self) -> dict[int, ASTNode]:
        """라인 번호 -> 노드 매핑 반환"""
        mapping = {}
        for node in self.get_top_level_nodes():
            for line in range(node.start_line, node.end_line + 1):
                mapping[line] = node
        return mapping

    @classmethod
    def from_file(cls, filepath: str | Path) -> 'JSASTParser':
        """파일에서 JS를 읽어 인스턴스 생성"""
        path = Path(filepath)
        with open(path, 'r', encoding='utf-8') as f:
            return cls(f.read())


def parse_js(source_code: str) -> dict:
    """JavaScript 소스를 파싱하여 AST dict 반환"""
    parser = JSASTParser(source_code)
    return parser.parse()


def parse_js_file(filepath: str | Path) -> dict:
    """파일에서 JavaScript를 파싱하여 AST dict 반환"""
    parser = JSASTParser.from_file(filepath)
    return parser.parse()
