"""다이어그램 생성기

의존성 그래프와 계층 분석 결과를 Mermaid 다이어그램으로 변환합니다.

생성 다이어그램:
- architecture.mermaid: 전체 아키텍처 구조
- modules.mermaid: 모듈간 관계
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from ..analyzer.hierarchy import HierarchyResult
from ..parser.dependency import DependencyGraph


@dataclass
class DiagramConfig:
    """다이어그램 설정"""
    direction: str = "TB"  # TB, LR, BT, RL
    theme: str = "default"  # default, dark, forest, neutral
    max_nodes: int = 50
    show_imports: bool = True
    show_exports: bool = True
    show_calls: bool = True
    group_by_module: bool = True


class DiagramGenerator:
    """Mermaid 다이어그램 생성기"""

    def __init__(self, config: Optional[DiagramConfig] = None):
        """
        Args:
            config: 다이어그램 설정
        """
        self.config = config or DiagramConfig()

    def generate_architecture_diagram(
        self,
        hierarchy_result: HierarchyResult,
        output_path: Optional[str | Path] = None
    ) -> str:
        """전체 아키텍처 다이어그램 생성

        Args:
            hierarchy_result: 계층 분석 결과
            output_path: 출력 파일 경로

        Returns:
            Mermaid 다이어그램 문자열
        """
        lines = [
            f"%%{{ init: {{ 'theme': '{self.config.theme}' }} }}%%",
            f"flowchart {self.config.direction}",
        ]

        # 계층 결과에서 아키텍처 정보 추출
        summary = hierarchy_result.final_summary or {}
        architecture = summary.get('architecture', summary.get('structure', {}))

        # 레이어/컴포넌트 정보가 있으면 사용
        if isinstance(architecture, dict):
            layers = architecture.get('layers', [])
            components = architecture.get('components', [])

            if layers:
                self._add_layers(lines, layers)
            elif components:
                self._add_components(lines, components)
            else:
                self._add_default_architecture(lines, summary)
        else:
            self._add_default_architecture(lines, summary)

        diagram = "\n".join(lines)

        if output_path:
            path = Path(output_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(diagram, encoding='utf-8')

        return diagram

    def _add_layers(self, lines: list, layers: list) -> None:
        """레이어 구조 추가"""
        for i, layer in enumerate(layers):
            if isinstance(layer, dict):
                name = layer.get('name', f'Layer{i}')
                components = layer.get('components', [])
                safe_name = self._safe_id(name)

                lines.append(f"    subgraph {safe_name}[\"{name}\"]")
                for comp in components[:10]:  # 최대 10개
                    if isinstance(comp, dict):
                        comp_name = comp.get('name', '')
                    else:
                        comp_name = str(comp)
                    if comp_name:
                        comp_id = self._safe_id(f"{name}_{comp_name}")
                        lines.append(f"        {comp_id}[\"{comp_name}\"]")
                lines.append("    end")
            elif isinstance(layer, str):
                safe_name = self._safe_id(layer)
                lines.append(f"    {safe_name}[\"{layer}\"]")

        # 레이어 간 연결
        for i in range(len(layers) - 1):
            if isinstance(layers[i], dict):
                from_name = layers[i].get('name', f'Layer{i}')
            else:
                from_name = str(layers[i])
            if isinstance(layers[i + 1], dict):
                to_name = layers[i + 1].get('name', f'Layer{i+1}')
            else:
                to_name = str(layers[i + 1])

            from_id = self._safe_id(from_name)
            to_id = self._safe_id(to_name)
            lines.append(f"    {from_id} --> {to_id}")

    def _add_components(self, lines: list, components: list) -> None:
        """컴포넌트 구조 추가"""
        comp_ids = []

        for comp in components[:self.config.max_nodes]:
            if isinstance(comp, dict):
                name = comp.get('name', '')
                comp_type = comp.get('type', 'component')
                dependencies = comp.get('dependencies', [])
            else:
                name = str(comp)
                comp_type = 'component'
                dependencies = []

            if not name:
                continue

            comp_id = self._safe_id(name)
            comp_ids.append(comp_id)

            # 노드 스타일 결정
            if comp_type in ('controller', 'api'):
                lines.append(f"    {comp_id}[[\"{name}\"]]")
            elif comp_type in ('service', 'logic'):
                lines.append(f"    {comp_id}((\"{name}\"))")
            elif comp_type in ('model', 'data'):
                lines.append(f"    {comp_id}[(\"{name}\")]")
            else:
                lines.append(f"    {comp_id}[\"{name}\"]")

            # 의존성 연결
            for dep in dependencies:
                dep_id = self._safe_id(str(dep))
                if dep_id != comp_id:
                    lines.append(f"    {comp_id} --> {dep_id}")

    def _add_default_architecture(self, lines: list, summary: dict) -> None:
        """기본 아키텍처 (모듈 기반)"""
        modules = summary.get('modules', summary.get('components', []))

        if not modules:
            lines.append("    App[\"Application\"]")
            return

        module_ids = []
        for module in modules[:self.config.max_nodes]:
            if isinstance(module, dict):
                name = module.get('name', '')
            else:
                name = str(module)

            if not name:
                continue

            mod_id = self._safe_id(name)
            module_ids.append(mod_id)
            lines.append(f"    {mod_id}[\"{name}\"]")

    def generate_modules_diagram(
        self,
        dependency_graph: Optional[DependencyGraph] = None,
        hierarchy_result: Optional[HierarchyResult] = None,
        output_path: Optional[str | Path] = None
    ) -> str:
        """모듈 관계 다이어그램 생성

        Args:
            dependency_graph: 의존성 그래프 (선택)
            hierarchy_result: 계층 분석 결과 (선택)
            output_path: 출력 파일 경로

        Returns:
            Mermaid 다이어그램 문자열
        """
        lines = [
            f"%%{{ init: {{ 'theme': '{self.config.theme}' }} }}%%",
            f"graph {self.config.direction}",
        ]

        if dependency_graph:
            self._add_dependency_nodes(lines, dependency_graph)
            self._add_dependency_edges(lines, dependency_graph)
        elif hierarchy_result:
            self._add_modules_from_hierarchy(lines, hierarchy_result)
        else:
            lines.append("    empty[\"No data available\"]")

        diagram = "\n".join(lines)

        if output_path:
            path = Path(output_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(diagram, encoding='utf-8')

        return diagram

    def _add_dependency_nodes(
        self,
        lines: list,
        graph: DependencyGraph
    ) -> None:
        """의존성 그래프에서 노드 추가"""
        # 함수/클래스 노드
        for node in graph.nodes[:self.config.max_nodes]:
            node_id = self._safe_id(node)
            lines.append(f"    {node_id}[\"{node}\"]")

        # import된 모듈
        if self.config.show_imports:
            seen_sources = set()
            for imp in graph.imports:
                if imp.source not in seen_sources:
                    seen_sources.add(imp.source)
                    source_id = self._safe_id(f"import_{imp.source}")
                    # 외부 모듈은 다른 스타일
                    if imp.source.startswith('.'):
                        lines.append(f"    {source_id}([\"{imp.source}\"])")
                    else:
                        lines.append(f"    {source_id}" + "{" + f'"{imp.source}"' + "}")

    def _add_dependency_edges(
        self,
        lines: list,
        graph: DependencyGraph
    ) -> None:
        """의존성 그래프에서 엣지 추가"""
        # 함수 호출 관계
        if self.config.show_calls:
            added_edges = set()
            for edge in graph.edges[:100]:  # 최대 100개 엣지
                from_node, to_node = edge
                edge_key = (from_node, to_node)
                if edge_key not in added_edges:
                    added_edges.add(edge_key)
                    from_id = self._safe_id(from_node)
                    to_id = self._safe_id(to_node)
                    lines.append(f"    {from_id} --> {to_id}")

        # import 관계
        if self.config.show_imports:
            for imp in graph.imports:
                source_id = self._safe_id(f"import_{imp.source}")
                for name in imp.imported_names[:5]:  # 각 import당 최대 5개
                    clean_name = name.replace(' as ', '_').replace('* as ', '')
                    if clean_name in graph.nodes:
                        name_id = self._safe_id(clean_name)
                        lines.append(f"    {source_id} -.-> {name_id}")

    def _add_modules_from_hierarchy(
        self,
        lines: list,
        hierarchy_result: HierarchyResult
    ) -> None:
        """계층 결과에서 모듈 관계 추출"""
        summary = hierarchy_result.final_summary or {}
        modules = summary.get('modules', summary.get('components', []))

        if not modules:
            lines.append("    app[\"Application\"]")
            return

        # 모듈과 의존성 추출
        module_info = []
        for module in modules[:self.config.max_nodes]:
            if isinstance(module, dict):
                name = module.get('name', '')
                deps = module.get('dependencies', module.get('imports', []))
                module_info.append((name, deps))
            else:
                module_info.append((str(module), []))

        # 그룹핑 여부에 따라 처리
        if self.config.group_by_module:
            # 카테고리별 그룹핑 시도
            categories: dict[str, list] = {}
            for name, deps in module_info:
                if not name:
                    continue
                # 간단한 카테고리 추론 (이름 기반)
                if 'controller' in name.lower() or 'api' in name.lower():
                    cat = 'Controllers'
                elif 'service' in name.lower() or 'logic' in name.lower():
                    cat = 'Services'
                elif 'model' in name.lower() or 'entity' in name.lower():
                    cat = 'Models'
                elif 'util' in name.lower() or 'helper' in name.lower():
                    cat = 'Utilities'
                else:
                    cat = 'Core'

                if cat not in categories:
                    categories[cat] = []
                categories[cat].append((name, deps))

            for cat, items in categories.items():
                cat_id = self._safe_id(cat)
                lines.append(f"    subgraph {cat_id}[\"{cat}\"]")
                for name, _ in items:
                    node_id = self._safe_id(name)
                    lines.append(f"        {node_id}[\"{name}\"]")
                lines.append("    end")

            # 의존성 엣지
            for name, deps in module_info:
                if not name:
                    continue
                from_id = self._safe_id(name)
                for dep in deps[:5]:
                    dep_name = dep if isinstance(dep, str) else dep.get('name', '')
                    if dep_name:
                        to_id = self._safe_id(dep_name)
                        lines.append(f"    {from_id} --> {to_id}")
        else:
            for name, deps in module_info:
                if not name:
                    continue
                node_id = self._safe_id(name)
                lines.append(f"    {node_id}[\"{name}\"]")

                for dep in deps[:5]:
                    dep_name = dep if isinstance(dep, str) else dep.get('name', '')
                    if dep_name:
                        to_id = self._safe_id(dep_name)
                        lines.append(f"    {node_id} --> {to_id}")

    def generate_flowchart(
        self,
        data_flow: dict,
        output_path: Optional[str | Path] = None
    ) -> str:
        """데이터 흐름 플로우차트 생성

        Args:
            data_flow: 데이터 흐름 정보
            output_path: 출력 파일 경로

        Returns:
            Mermaid 다이어그램 문자열
        """
        lines = [
            f"%%{{ init: {{ 'theme': '{self.config.theme}' }} }}%%",
            f"flowchart {self.config.direction}",
        ]

        flows = data_flow.get('flows', [])
        if not flows:
            # 단순 입력-처리-출력 구조
            inputs = data_flow.get('inputs', ['Input'])
            outputs = data_flow.get('outputs', ['Output'])

            for i, inp in enumerate(inputs[:5]):
                inp_id = self._safe_id(f"input_{i}")
                lines.append(f"    {inp_id}([{inp}])")

            lines.append("    process{{Process}}")

            for i, out in enumerate(outputs[:5]):
                out_id = self._safe_id(f"output_{i}")
                lines.append(f"    {out_id}([{out}])")

            for i in range(len(inputs[:5])):
                inp_id = self._safe_id(f"input_{i}")
                lines.append(f"    {inp_id} --> process")

            for i in range(len(outputs[:5])):
                out_id = self._safe_id(f"output_{i}")
                lines.append(f"    process --> {out_id}")
        else:
            for flow_idx, flow in enumerate(flows[:5]):
                if isinstance(flow, dict):
                    name = flow.get('name', f'Flow{flow_idx}')
                    steps = flow.get('steps', [])
                else:
                    name = f'Flow{flow_idx}'
                    steps = [str(flow)]

                if steps:
                    flow_id = self._safe_id(f"flow_{flow_idx}")
                    lines.append(f"    subgraph {flow_id}[\"{name}\"]")

                    step_ids = []
                    for i, step in enumerate(steps[:10]):
                        step_id = self._safe_id(f"step_{flow_idx}_{i}")
                        step_ids.append(step_id)
                        lines.append(f"        {step_id}[\"{step}\"]")

                    for i in range(len(step_ids) - 1):
                        lines.append(f"        {step_ids[i]} --> {step_ids[i+1]}")

                    lines.append("    end")

        diagram = "\n".join(lines)

        if output_path:
            path = Path(output_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(diagram, encoding='utf-8')

        return diagram

    def _safe_id(self, name: str) -> str:
        """Mermaid에서 안전한 ID 생성"""
        # 특수문자 제거/변환
        safe = name.replace(' ', '_')
        safe = safe.replace('.', '_')
        safe = safe.replace('-', '_')
        safe = safe.replace('/', '_')
        safe = safe.replace('<', '')
        safe = safe.replace('>', '')
        safe = safe.replace('@', '_at_')
        safe = safe.replace('*', '')

        # 숫자로 시작하면 접두사 추가
        if safe and safe[0].isdigit():
            safe = 'n_' + safe

        # 빈 문자열이면 기본값
        if not safe:
            safe = 'node'

        return safe


def generate_architecture_diagram(
    hierarchy_result: HierarchyResult,
    output_path: Optional[str | Path] = None,
    config: Optional[DiagramConfig] = None
) -> str:
    """아키텍처 다이어그램 생성 편의 함수

    Args:
        hierarchy_result: 계층 분석 결과
        output_path: 출력 파일 경로
        config: 다이어그램 설정

    Returns:
        Mermaid 다이어그램 문자열
    """
    generator = DiagramGenerator(config)
    return generator.generate_architecture_diagram(hierarchy_result, output_path)


def generate_modules_diagram(
    dependency_graph: Optional[DependencyGraph] = None,
    hierarchy_result: Optional[HierarchyResult] = None,
    output_path: Optional[str | Path] = None,
    config: Optional[DiagramConfig] = None
) -> str:
    """모듈 관계 다이어그램 생성 편의 함수

    Args:
        dependency_graph: 의존성 그래프
        hierarchy_result: 계층 분석 결과
        output_path: 출력 파일 경로
        config: 다이어그램 설정

    Returns:
        Mermaid 다이어그램 문자열
    """
    generator = DiagramGenerator(config)
    return generator.generate_modules_diagram(
        dependency_graph, hierarchy_result, output_path
    )
