"""리팩토링 가이드 생성기

코드 품질 이슈를 분석하고 우선순위별로 분류된 리팩토링 가이드를 생성합니다.

우선순위:
- 긴급 (urgent): 즉시 수정 필요 (보안, 성능 심각)
- 권장 (recommended): 가능한 빨리 수정 권장
- 개선 (improvement): 코드 품질 향상을 위한 개선사항
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Optional

from ..analyzer.hierarchy import HierarchyResult


class Priority(Enum):
    """이슈 우선순위"""
    URGENT = "urgent"
    RECOMMENDED = "recommended"
    IMPROVEMENT = "improvement"

    @property
    def emoji(self) -> str:
        """우선순위별 이모지"""
        return {
            Priority.URGENT: "[긴급]",
            Priority.RECOMMENDED: "[권장]",
            Priority.IMPROVEMENT: "[개선]",
        }[self]

    @property
    def label(self) -> str:
        """한글 레이블"""
        return {
            Priority.URGENT: "긴급",
            Priority.RECOMMENDED: "권장",
            Priority.IMPROVEMENT: "개선",
        }[self]


@dataclass
class RefactorIssue:
    """리팩토링 이슈"""
    title: str
    description: str
    priority: Priority
    category: str = "general"
    location: Optional[str] = None
    before_code: Optional[str] = None
    after_code: Optional[str] = None
    impact: Optional[str] = None
    effort: Optional[str] = None  # low, medium, high

    def to_dict(self) -> dict:
        return {
            "title": self.title,
            "description": self.description,
            "priority": self.priority.value,
            "category": self.category,
            "location": self.location,
            "before_code": self.before_code,
            "after_code": self.after_code,
            "impact": self.impact,
            "effort": self.effort,
        }


@dataclass
class RefactorGuideConfig:
    """리팩토링 가이드 설정"""
    include_code_examples: bool = True
    include_roadmap: bool = True
    max_issues_per_priority: int = 20
    group_by_category: bool = True


class RefactorGuideGenerator:
    """리팩토링 가이드 생성기"""

    # 이슈 카테고리
    CATEGORIES = {
        "security": "보안",
        "performance": "성능",
        "maintainability": "유지보수성",
        "readability": "가독성",
        "architecture": "아키텍처",
        "testing": "테스트",
        "documentation": "문서화",
        "general": "일반",
    }

    def __init__(self, config: Optional[RefactorGuideConfig] = None):
        """
        Args:
            config: 가이드 설정
        """
        self.config = config or RefactorGuideConfig()

    def generate(
        self,
        hierarchy_result: HierarchyResult,
        project_name: str = "Project",
        output_path: Optional[str | Path] = None
    ) -> str:
        """리팩토링 가이드 생성

        Args:
            hierarchy_result: 계층 분석 결과
            project_name: 프로젝트 이름
            output_path: 출력 파일 경로

        Returns:
            생성된 Markdown 문자열
        """
        # 이슈 추출
        issues = self._extract_issues(hierarchy_result)

        # 우선순위별 분류
        issues_by_priority = self._classify_by_priority(issues)

        # 보고서 생성
        sections = []
        sections.append(self._generate_header(project_name))
        sections.append(self._generate_overview(issues_by_priority))

        # 우선순위별 섹션
        for priority in [Priority.URGENT, Priority.RECOMMENDED, Priority.IMPROVEMENT]:
            priority_issues = issues_by_priority.get(priority, [])
            if priority_issues:
                sections.append(self._generate_priority_section(priority, priority_issues))

        # 로드맵
        if self.config.include_roadmap:
            sections.append(self._generate_roadmap(issues_by_priority))

        sections.append(self._generate_footer())

        report = "\n\n".join(filter(None, sections))

        # 파일 저장
        if output_path:
            path = Path(output_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(report, encoding='utf-8')

        return report

    def _extract_issues(self, hierarchy_result: HierarchyResult) -> list[RefactorIssue]:
        """계층 결과에서 이슈 추출"""
        issues = []

        # 최종 요약에서 이슈 추출
        if hierarchy_result.final_summary:
            issues.extend(self._parse_issues_from_data(hierarchy_result.final_summary))

        # 각 레벨에서 이슈 추출
        for level in range(1, 4):
            level_results = hierarchy_result.get_level(level)
            for result in level_results:
                if result.success and result.analysis:
                    issues.extend(self._parse_issues_from_data(result.analysis))

        # 중복 제거 (제목 기준)
        seen_titles = set()
        unique_issues = []
        for issue in issues:
            if issue.title not in seen_titles:
                seen_titles.add(issue.title)
                unique_issues.append(issue)

        return unique_issues

    def _parse_issues_from_data(self, data: dict) -> list[RefactorIssue]:
        """데이터에서 이슈 파싱"""
        issues = []

        # issues 키에서 이슈 추출
        raw_issues = data.get('issues', data.get('problems', data.get('refactoring', [])))

        if isinstance(raw_issues, list):
            for raw in raw_issues:
                issue = self._parse_single_issue(raw)
                if issue:
                    issues.append(issue)
        elif isinstance(raw_issues, dict):
            for category, category_issues in raw_issues.items():
                if isinstance(category_issues, list):
                    for raw in category_issues:
                        issue = self._parse_single_issue(raw, category)
                        if issue:
                            issues.append(issue)

        # quality_issues 키도 확인
        quality_issues = data.get('quality_issues', [])
        if isinstance(quality_issues, list):
            for raw in quality_issues:
                issue = self._parse_single_issue(raw)
                if issue:
                    issues.append(issue)

        # code_smells 키도 확인
        code_smells = data.get('code_smells', [])
        if isinstance(code_smells, list):
            for raw in code_smells:
                issue = self._parse_single_issue(raw, "maintainability")
                if issue:
                    issues.append(issue)

        return issues

    def _parse_single_issue(
        self,
        raw: Any,
        default_category: str = "general"
    ) -> Optional[RefactorIssue]:
        """단일 이슈 파싱"""
        if isinstance(raw, str):
            return RefactorIssue(
                title=raw[:100],
                description=raw,
                priority=Priority.IMPROVEMENT,
                category=default_category,
            )

        if isinstance(raw, dict):
            title = raw.get('title', raw.get('name', raw.get('issue', '')))
            if not title:
                return None

            # 우선순위 결정
            priority_str = raw.get('priority', raw.get('severity', 'improvement'))
            priority = self._parse_priority(priority_str)

            return RefactorIssue(
                title=title,
                description=raw.get('description', raw.get('message', '')),
                priority=priority,
                category=raw.get('category', raw.get('type', default_category)),
                location=raw.get('location', raw.get('file', raw.get('line'))),
                before_code=raw.get('before', raw.get('before_code', raw.get('current'))),
                after_code=raw.get('after', raw.get('after_code', raw.get('suggested'))),
                impact=raw.get('impact'),
                effort=raw.get('effort', raw.get('difficulty')),
            )

        return None

    def _parse_priority(self, priority_str: str) -> Priority:
        """우선순위 문자열 파싱"""
        if not priority_str:
            return Priority.IMPROVEMENT

        priority_str = str(priority_str).lower()

        urgent_keywords = ['urgent', 'critical', 'high', 'error', 'severe', '긴급', '심각']
        recommended_keywords = ['recommended', 'medium', 'warning', 'moderate', '권장', '중간']

        for kw in urgent_keywords:
            if kw in priority_str:
                return Priority.URGENT

        for kw in recommended_keywords:
            if kw in priority_str:
                return Priority.RECOMMENDED

        return Priority.IMPROVEMENT

    def _classify_by_priority(
        self,
        issues: list[RefactorIssue]
    ) -> dict[Priority, list[RefactorIssue]]:
        """우선순위별 분류"""
        result = {
            Priority.URGENT: [],
            Priority.RECOMMENDED: [],
            Priority.IMPROVEMENT: [],
        }

        for issue in issues:
            result[issue.priority].append(issue)

        # 각 우선순위별 최대 개수 제한
        for priority in result:
            result[priority] = result[priority][:self.config.max_issues_per_priority]

        return result

    def _generate_header(self, project_name: str) -> str:
        """헤더 생성"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return f"""# {project_name} - 리팩토링 가이드

> 자동 생성: {timestamp}
> Generated by CodeLens"""

    def _generate_overview(
        self,
        issues_by_priority: dict[Priority, list[RefactorIssue]]
    ) -> str:
        """개요 섹션 생성"""
        lines = ["## 개요", ""]

        total = sum(len(v) for v in issues_by_priority.values())
        urgent = len(issues_by_priority.get(Priority.URGENT, []))
        recommended = len(issues_by_priority.get(Priority.RECOMMENDED, []))
        improvement = len(issues_by_priority.get(Priority.IMPROVEMENT, []))

        lines.append(f"총 **{total}개**의 리팩토링 항목이 발견되었습니다.")
        lines.append("")
        lines.append("| 우선순위 | 개수 |")
        lines.append("|----------|------|")
        lines.append(f"| {Priority.URGENT.emoji} 긴급 | {urgent} |")
        lines.append(f"| {Priority.RECOMMENDED.emoji} 권장 | {recommended} |")
        lines.append(f"| {Priority.IMPROVEMENT.emoji} 개선 | {improvement} |")

        return "\n".join(lines)

    def _generate_priority_section(
        self,
        priority: Priority,
        issues: list[RefactorIssue]
    ) -> str:
        """우선순위별 섹션 생성"""
        lines = [f"## {priority.emoji} {priority.label} 사항", ""]

        if self.config.group_by_category:
            # 카테고리별 그룹핑
            by_category: dict[str, list[RefactorIssue]] = {}
            for issue in issues:
                cat = issue.category
                if cat not in by_category:
                    by_category[cat] = []
                by_category[cat].append(issue)

            for category, cat_issues in by_category.items():
                cat_label = self.CATEGORIES.get(category, category)
                lines.append(f"### {cat_label}")
                lines.append("")

                for issue in cat_issues:
                    self._format_issue(issue, lines)
        else:
            for issue in issues:
                self._format_issue(issue, lines)

        return "\n".join(lines)

    def _format_issue(self, issue: RefactorIssue, lines: list) -> None:
        """이슈 포맷팅"""
        lines.append(f"#### {issue.title}")

        if issue.description:
            lines.append(f"\n{issue.description}")

        if issue.location:
            lines.append(f"\n**위치**: `{issue.location}`")

        if issue.impact:
            lines.append(f"\n**영향**: {issue.impact}")

        if issue.effort:
            effort_label = {"low": "낮음", "medium": "중간", "high": "높음"}.get(
                issue.effort.lower(), issue.effort
            )
            lines.append(f"\n**난이도**: {effort_label}")

        # 코드 예시
        if self.config.include_code_examples:
            if issue.before_code and issue.after_code:
                lines.append("\n**Before**:")
                lines.append("```javascript")
                lines.append(issue.before_code)
                lines.append("```")
                lines.append("\n**After**:")
                lines.append("```javascript")
                lines.append(issue.after_code)
                lines.append("```")
            elif issue.before_code:
                lines.append("\n**현재 코드**:")
                lines.append("```javascript")
                lines.append(issue.before_code)
                lines.append("```")
            elif issue.after_code:
                lines.append("\n**권장 코드**:")
                lines.append("```javascript")
                lines.append(issue.after_code)
                lines.append("```")

        lines.append("")

    def _generate_roadmap(
        self,
        issues_by_priority: dict[Priority, list[RefactorIssue]]
    ) -> str:
        """로드맵 테이블 생성"""
        lines = ["## 리팩토링 로드맵", ""]

        lines.append("| 순서 | 항목 | 우선순위 | 카테고리 | 난이도 |")
        lines.append("|------|------|----------|----------|--------|")

        order = 1
        for priority in [Priority.URGENT, Priority.RECOMMENDED, Priority.IMPROVEMENT]:
            for issue in issues_by_priority.get(priority, []):
                cat_label = self.CATEGORIES.get(issue.category, issue.category)
                effort = issue.effort or "-"
                lines.append(
                    f"| {order} | {issue.title[:40]} | {priority.label} | {cat_label} | {effort} |"
                )
                order += 1
                if order > 30:  # 최대 30개
                    break
            if order > 30:
                break

        return "\n".join(lines)

    def _generate_footer(self) -> str:
        """푸터 생성"""
        return """---

*이 문서는 CodeLens에 의해 자동 생성되었습니다.*"""


def generate_refactor_guide(
    hierarchy_result: HierarchyResult,
    project_name: str = "Project",
    output_path: Optional[str | Path] = None,
    config: Optional[RefactorGuideConfig] = None
) -> str:
    """리팩토링 가이드를 생성하는 편의 함수

    Args:
        hierarchy_result: 계층 분석 결과
        project_name: 프로젝트 이름
        output_path: 출력 파일 경로
        config: 가이드 설정

    Returns:
        생성된 Markdown 문자열
    """
    generator = RefactorGuideGenerator(config)
    return generator.generate(hierarchy_result, project_name, output_path)
