"""CodeLens Reporter Module

분석 결과를 다양한 형식의 보고서로 변환합니다.

Modules:
- structure_report: 구조 설명서 생성
- refactor_guide: 리팩토링 가이드 생성
- diagram_generator: Mermaid 다이어그램 생성
"""

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

from .structure_report import (
    StructureReportGenerator,
    StructureReportConfig,
    generate_structure_report,
)

from .refactor_guide import (
    RefactorGuideGenerator,
    RefactorGuideConfig,
    RefactorIssue,
    Priority,
    generate_refactor_guide,
)

from .diagram_generator import (
    DiagramGenerator,
    DiagramConfig,
    generate_architecture_diagram,
    generate_modules_diagram,
)

from ..analyzer.hierarchy import HierarchyResult
from ..parser.dependency import DependencyGraph


@dataclass
class ReportMetadata:
    """보고서 메타데이터"""
    project_name: str
    generated_at: str
    codelens_version: str
    files_generated: list[str]


class ReportGenerator:
    """통합 보고서 생성기

    모든 보고서를 한번에 생성합니다.
    """

    def __init__(
        self,
        output_dir: str | Path,
        project_name: str = "Project",
        structure_config: Optional[StructureReportConfig] = None,
        refactor_config: Optional[RefactorGuideConfig] = None,
        diagram_config: Optional[DiagramConfig] = None
    ):
        """
        Args:
            output_dir: 출력 디렉토리
            project_name: 프로젝트 이름
            structure_config: 구조 보고서 설정
            refactor_config: 리팩토링 가이드 설정
            diagram_config: 다이어그램 설정
        """
        self.output_dir = Path(output_dir)
        self.project_name = project_name

        self.structure_gen = StructureReportGenerator(structure_config)
        self.refactor_gen = RefactorGuideGenerator(refactor_config)
        self.diagram_gen = DiagramGenerator(diagram_config)

    def generate_all(
        self,
        hierarchy_result: HierarchyResult,
        dependency_graph: Optional[DependencyGraph] = None
    ) -> ReportMetadata:
        """모든 보고서 생성

        Args:
            hierarchy_result: 계층 분석 결과
            dependency_graph: 의존성 그래프 (선택)

        Returns:
            ReportMetadata 객체
        """
        self.output_dir.mkdir(parents=True, exist_ok=True)
        files_generated = []

        # 1. 구조 설명서
        report_path = self.output_dir / "report.md"
        self.structure_gen.generate(
            hierarchy_result,
            self.project_name,
            report_path
        )
        files_generated.append("report.md")

        # 2. 리팩토링 가이드
        refactor_path = self.output_dir / "refactor.md"
        self.refactor_gen.generate(
            hierarchy_result,
            self.project_name,
            refactor_path
        )
        files_generated.append("refactor.md")

        # 3. 아키텍처 다이어그램
        arch_path = self.output_dir / "architecture.mermaid"
        self.diagram_gen.generate_architecture_diagram(
            hierarchy_result,
            arch_path
        )
        files_generated.append("architecture.mermaid")

        # 4. 모듈 관계 다이어그램
        modules_path = self.output_dir / "modules.mermaid"
        self.diagram_gen.generate_modules_diagram(
            dependency_graph,
            hierarchy_result,
            modules_path
        )
        files_generated.append("modules.mermaid")

        # 5. 메타데이터
        from .. import __version__
        metadata = ReportMetadata(
            project_name=self.project_name,
            generated_at=datetime.now().isoformat(),
            codelens_version=__version__,
            files_generated=files_generated
        )

        metadata_path = self.output_dir / "metadata.json"
        metadata_dict = {
            "project_name": metadata.project_name,
            "generated_at": metadata.generated_at,
            "codelens_version": metadata.codelens_version,
            "files_generated": metadata.files_generated,
        }
        metadata_path.write_text(
            json.dumps(metadata_dict, ensure_ascii=False, indent=2),
            encoding='utf-8'
        )
        files_generated.append("metadata.json")

        return metadata


def generate_reports(
    hierarchy_result: HierarchyResult,
    output_dir: str | Path,
    project_name: str = "Project",
    dependency_graph: Optional[DependencyGraph] = None
) -> ReportMetadata:
    """모든 보고서를 생성하는 편의 함수

    Args:
        hierarchy_result: 계층 분석 결과
        output_dir: 출력 디렉토리
        project_name: 프로젝트 이름
        dependency_graph: 의존성 그래프

    Returns:
        ReportMetadata 객체
    """
    generator = ReportGenerator(output_dir, project_name)
    return generator.generate_all(hierarchy_result, dependency_graph)


__all__ = [
    # Structure Report
    'StructureReportGenerator',
    'StructureReportConfig',
    'generate_structure_report',
    # Refactor Guide
    'RefactorGuideGenerator',
    'RefactorGuideConfig',
    'RefactorIssue',
    'Priority',
    'generate_refactor_guide',
    # Diagram Generator
    'DiagramGenerator',
    'DiagramConfig',
    'generate_architecture_diagram',
    'generate_modules_diagram',
    # Main Reporter
    'ReportGenerator',
    'ReportMetadata',
    'generate_reports',
]
