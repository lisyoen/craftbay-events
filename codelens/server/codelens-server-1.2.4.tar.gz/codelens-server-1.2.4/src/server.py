# -*- coding: utf-8 -*-
"""CodeLens REST API Server

FastAPI 기반 코드 분석 서버
"""

import asyncio
import logging
import os
import shutil
import tempfile
import uuid
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Optional

import aiofiles
import yaml
from fastapi import FastAPI, File, HTTPException, UploadFile, BackgroundTasks
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field

# 로깅 설정
logger = logging.getLogger(__name__)


class JobPhase(str, Enum):
    """작업 단계"""
    PENDING = "pending"
    PARSING = "parsing"
    CHUNKING = "chunking"
    ANALYZING = "analyzing"
    MERGING = "merging"
    REPORTING = "reporting"
    COMPLETED = "completed"
    FAILED = "failed"


class JobStatus(str, Enum):
    """작업 상태"""
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class AnalysisJob:
    """분석 작업"""
    job_id: str
    status: JobStatus = JobStatus.QUEUED
    phase: JobPhase = JobPhase.PENDING
    progress: float = 0.0
    message: str = ""
    created_at: datetime = field(default_factory=datetime.now)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    source_path: Optional[str] = None
    output_dir: Optional[str] = None
    project_name: str = "Project"
    error: Optional[str] = None
    result_files: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """딕셔너리 변환"""
        return {
            "job_id": self.job_id,
            "status": self.status.value,
            "phase": self.phase.value,
            "progress": self.progress,
            "message": self.message,
            "created_at": self.created_at.isoformat(),
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "project_name": self.project_name,
            "error": self.error,
            "result_files": list(self.result_files.keys()) if self.result_files else []
        }


# 작업 저장소 (실제 운영 시 Redis 등으로 대체)
_jobs: dict[str, AnalysisJob] = {}
_config: dict = {}


def load_config() -> dict:
    """설정 파일 로드"""
    config_path = Path(__file__).parent.parent / "config" / "settings.yaml"
    if config_path.exists():
        with open(config_path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    return {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    """앱 생명주기 관리"""
    global _config
    _config = load_config()
    logger.info("CodeLens Server starting...")
    yield
    logger.info("CodeLens Server shutting down...")


app = FastAPI(
    title="CodeLens API",
    description="JavaScript/HTML 코드 분석 서버",
    version="0.1.0",
    lifespan=lifespan
)


# Pydantic 모델
class AnalyzeRequest(BaseModel):
    """분석 요청 모델"""
    source_path: Optional[str] = Field(None, description="분석할 소스 파일/디렉토리 경로")
    project_name: Optional[str] = Field("Project", description="프로젝트 이름")


class JobStatusResponse(BaseModel):
    """작업 상태 응답"""
    job_id: str
    status: str
    phase: str
    progress: float
    message: str
    created_at: str
    started_at: Optional[str]
    completed_at: Optional[str]
    project_name: str
    error: Optional[str]
    result_files: list[str]


class HealthResponse(BaseModel):
    """헬스체크 응답"""
    status: str
    version: str
    llm_status: str



def simple_chunk(code: str, target_size_kb: int, filename: str) -> list:
    """단순 텍스트 청킹 - Chunk 객체 반환"""
    from .parser.chunker import Chunk
    from .parser.ast_parser import ASTNode
    
    target_size = target_size_kb * 1024
    chunks = []
    lines = code.split('\n')
    
    current_chunk = []
    current_size = 0
    chunk_start = 1
    
    for i, line in enumerate(lines):
        line_size = len(line.encode('utf-8')) + 1
        
        if current_size + line_size > target_size and current_chunk:
            chunk_code = '\n'.join(current_chunk)
            chunks.append(Chunk(
                chunk_id=len(chunks),
                nodes=[],
                start_line=chunk_start,
                end_line=chunk_start + len(current_chunk) - 1,
                size_bytes=current_size,
                source_code=chunk_code,
                description=f"{filename} chunk {len(chunks)+1}"
            ))
            current_chunk = []
            current_size = 0
            chunk_start = i + 1
        
        current_chunk.append(line)
        current_size += line_size
    
    if current_chunk:
        chunk_code = '\n'.join(current_chunk)
        chunks.append(Chunk(
            chunk_id=len(chunks),
            nodes=[],
            start_line=chunk_start,
            end_line=chunk_start + len(current_chunk) - 1,
            size_bytes=current_size,
            source_code=chunk_code,
            description=f"{filename}" if not chunks else f"{filename} chunk {len(chunks)+1}"
        ))
    
    return chunks


async def run_analysis(job: AnalysisJob) -> None:
    """비동기 분석 실행"""
    from .parser import HTMLScriptExtractor, ASTChunker
    from .analyzer import ChunkAnalyzer, HierarchyMerger, LLMClient, LLMConfig
    from .reporter import ReportGenerator

    job.status = JobStatus.RUNNING
    job.started_at = datetime.now()

    try:
        # 1. 파싱 단계
        job.phase = JobPhase.PARSING
        job.message = "소스 파일 파싱 중..."
        job.progress = 0.1

        source_path = Path(job.source_path)
        if not source_path.exists():
            raise FileNotFoundError(f"Source path not found: {source_path}")

        # 파일 타입에 따른 파싱
        all_code = ""
        file_ext = source_path.suffix.lower() if source_path.is_file() else ""
        
        if source_path.is_file():
            if file_ext == '.java':
                # Java 파일
                all_code = source_path.read_text(encoding='utf-8', errors='ignore')
            elif file_ext == '.html':
                # HTML 파일에서 JS 추출
                html_content = source_path.read_text(encoding='utf-8', errors='ignore')
                extractor = HTMLScriptExtractor(html_content)
                scripts = extractor.extract()
                all_code = "\n".join(s.content for s in scripts)
            else:
                # JS/TS 파일
                all_code = source_path.read_text(encoding='utf-8', errors='ignore')
        else:
            # 디렉토리인 경우
            for ext in ['.js', '.jsx', '.ts', '.tsx', '.html', '.java']:
                for file_path in source_path.rglob(f'*{ext}'):
                    if any(exclude in str(file_path) for exclude in ['node_modules', 'dist', 'build', 'target']):
                        continue
                    try:
                        if ext == '.html':
                            html_content = file_path.read_text(encoding='utf-8', errors='ignore')
                            extractor = HTMLScriptExtractor(html_content)
                            scripts = extractor.extract()
                            all_code += "\n".join(s.content for s in scripts) + "\n"
                        else:
                            all_code += file_path.read_text(encoding='utf-8', errors='ignore') + "\n"
                    except Exception as e:
                        logger.warning(f"Failed to read {file_path}: {e}")

        if not all_code.strip():
            raise ValueError("No code found to analyze")

        # 2. 청킹 단계
        job.phase = JobPhase.CHUNKING
        job.message = "코드 청킹 중..."
        job.progress = 0.2

        chunking_config = _config.get('chunking', {})
        target_size_kb = chunking_config.get('target_size_kb', 40)
        max_size_kb = chunking_config.get('max_size_kb', 60)
        
        # 파일 타입에 따른 청킹
        if file_ext == '.java':
            # Java: javalang 파서 사용 또는 단순 텍스트 청킹
            chunks = simple_chunk(all_code, target_size_kb, source_path.name)
        elif file_ext in ['.js', '.jsx', '.ts', '.tsx']:
            # JS/TS: AST 파서 사용
            try:
                from .parser.ast_parser import JSASTParser
                parser = JSASTParser(all_code)
                ast_result = parser.parse()
                chunker = ASTChunker()
                chunks = chunker.create_chunks(
                    all_code,
                    ast_result.ast,
                    target_size_kb=target_size_kb,
                    max_size_kb=max_size_kb
                )
            except Exception as e:
                logger.warning(f"AST parsing failed, using simple chunking: {e}")
                chunks = simple_chunk(all_code, target_size_kb, source_path.name)
        else:
            # 기타: 단순 텍스트 청킹
            chunks = simple_chunk(all_code, target_size_kb, source_path.name)

        # 3. LLM 분석 단계
        job.phase = JobPhase.ANALYZING
        job.message = "LLM 청크 분석 중..."

        llm_config_data = _config.get('llm', {})
        llm_config = LLMConfig(
            base_url=llm_config_data.get('base_url', 'http://localhost:4000/v1'),
            model=llm_config_data.get('model', 'gpt-4'),
            api_key=os.environ.get('CODELENS_API_KEY', llm_config_data.get('api_key', '')),
            max_output_tokens=llm_config_data.get('max_output_tokens', 4096),
            temperature=llm_config_data.get('temperature', 0.2),
            timeout=llm_config_data.get('timeout', 120)
        )

        analysis_config = _config.get('analysis', {})
        analyzer = ChunkAnalyzer(
            config=llm_config,
            parallel_workers=analysis_config.get('parallel_workers', 3)
        )

        total_chunks = len(chunks)

        def update_progress(progress):
            job.progress = 0.2 + (progress.completed / progress.total) * 0.4
            job.message = f"청크 분석 중... ({progress.completed}/{progress.total})"

        chunk_results = analyzer.analyze_chunks(
            chunks,
            file_path=str(source_path),
            progress_callback=update_progress,
            save_results=False
        )

        # 4. 계층 통합 단계
        job.phase = JobPhase.MERGING
        job.message = "분석 결과 통합 중..."
        job.progress = 0.7

        hierarchy_config = _config.get('hierarchy', {})
        merger = HierarchyMerger(
            config=llm_config,
            group_sizes=hierarchy_config.get('group_sizes', {})
        )

        def update_merge_progress(current, total, level):
            job.message = f"Level {level} 통합 중... ({current}/{total})"
            job.progress = 0.7 + (current / total) * 0.15

        hierarchy_result = merger.build_hierarchy(
            chunk_results,
            progress_callback=update_merge_progress
        )

        # 5. 보고서 생성 단계
        job.phase = JobPhase.REPORTING
        job.message = "보고서 생성 중..."
        job.progress = 0.9

        output_dir = Path(job.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        generator = ReportGenerator(output_dir=output_dir, project_name=job.project_name)
        report_metadata = generator.generate_all(
            hierarchy_result=hierarchy_result
        )
        generated_files = {Path(f).stem: f for f in report_metadata.files_generated} if hasattr(report_metadata, 'files_generated') else {}

        job.result_files = {
            name: str(path) for name, path in generated_files.items()
        }

        # 완료
        job.phase = JobPhase.COMPLETED
        job.status = JobStatus.COMPLETED
        job.progress = 1.0
        job.message = "분석 완료"
        job.completed_at = datetime.now()

    except Exception as e:
        logger.exception("Analysis failed")
        job.phase = JobPhase.FAILED
        job.status = JobStatus.FAILED
        job.error = str(e)
        job.message = f"분석 실패: {str(e)}"
        job.completed_at = datetime.now()


@app.get("/health", response_model=HealthResponse)
async def health_check():
    """서버 상태 확인"""
    llm_status = "unknown"

    try:
        from .analyzer import LLMClient, LLMConfig
        llm_config_data = _config.get('llm', {})
        config = LLMConfig(
            base_url=llm_config_data.get('base_url', 'http://localhost:4000/v1'),
            model=llm_config_data.get('model', 'gpt-4'),
            api_key=os.environ.get('CODELENS_API_KEY', llm_config_data.get('api_key', '')),
            timeout=5
        )
        client = LLMClient(config)
        # 간단한 연결 테스트
        response = client.complete("Say 'ok'", max_tokens=10)
        llm_status = "connected" if response.success else "error"
    except Exception as e:
        llm_status = f"error: {str(e)}"

    return HealthResponse(
        status="ok",
        version="0.1.0",
        llm_status=llm_status
    )


@app.post("/analyze")
async def analyze(
    background_tasks: BackgroundTasks,
    request: AnalyzeRequest = None,
    file: UploadFile = File(None)
):
    """코드 분석 시작

    파일 업로드 또는 경로 지정으로 분석을 시작합니다.
    """
    job_id = str(uuid.uuid4())
    output_dir = tempfile.mkdtemp(prefix=f"codelens_{job_id}_")

    job = AnalysisJob(
        job_id=job_id,
        output_dir=output_dir
    )

    if file and file.filename:
        # 파일 업로드 처리
        server_config = _config.get('server', {})
        max_size = server_config.get('max_file_size_mb', 50) * 1024 * 1024

        # 임시 파일로 저장
        upload_path = Path(output_dir) / "upload" / file.filename
        upload_path.parent.mkdir(parents=True, exist_ok=True)

        total_size = 0
        async with aiofiles.open(upload_path, 'wb') as f:
            while chunk := await file.read(8192):
                total_size += len(chunk)
                if total_size > max_size:
                    raise HTTPException(
                        status_code=413,
                        detail=f"File too large. Max size: {server_config.get('max_file_size_mb', 50)}MB"
                    )
                await f.write(chunk)

        job.source_path = str(upload_path)
        job.project_name = Path(file.filename).stem

    elif request and request.source_path:
        # 경로 지정
        source_path = Path(request.source_path)
        if not source_path.exists():
            raise HTTPException(status_code=404, detail="Source path not found")
        job.source_path = str(source_path)
        job.project_name = request.project_name or source_path.stem

    else:
        raise HTTPException(
            status_code=400,
            detail="Either file upload or source_path is required"
        )

    _jobs[job_id] = job
    background_tasks.add_task(run_analysis, job)

    return JSONResponse(
        status_code=202,
        content={
            "job_id": job_id,
            "message": "Analysis started",
            "status_url": f"/status/{job_id}"
        }
    )


@app.get("/status/{job_id}", response_model=JobStatusResponse)
async def get_status(job_id: str):
    """작업 상태 조회"""
    if job_id not in _jobs:
        raise HTTPException(status_code=404, detail="Job not found")

    job = _jobs[job_id]
    return JobStatusResponse(**job.to_dict())


@app.get("/result/{job_id}")
async def get_result(job_id: str, file_type: Optional[str] = None):
    """분석 결과 다운로드

    Args:
        job_id: 작업 ID
        file_type: 파일 타입 (report, refactor, architecture, modules, metadata)
                   지정하지 않으면 전체 결과를 zip으로 다운로드
    """
    if job_id not in _jobs:
        raise HTTPException(status_code=404, detail="Job not found")

    job = _jobs[job_id]

    if job.status != JobStatus.COMPLETED:
        raise HTTPException(
            status_code=400,
            detail=f"Job not completed. Current status: {job.status.value}"
        )

    if not job.result_files:
        raise HTTPException(status_code=404, detail="No result files found")

    if file_type:
        # 특정 파일 다운로드
        if file_type not in job.result_files:
            raise HTTPException(
                status_code=404,
                detail=f"File type '{file_type}' not found. Available: {list(job.result_files.keys())}"
            )
        file_path = Path(job.result_files[file_type])
        if not file_path.exists():
            raise HTTPException(status_code=404, detail="Result file not found")
        return FileResponse(
            path=file_path,
            filename=file_path.name,
            media_type="application/octet-stream"
        )

    # 전체 결과를 zip으로
    output_dir = Path(job.output_dir)
    zip_path = output_dir / f"{job.project_name}_results.zip"

    if not zip_path.exists():
        shutil.make_archive(
            str(zip_path.with_suffix('')),
            'zip',
            root_dir=output_dir
        )

    return FileResponse(
        path=zip_path,
        filename=f"{job.project_name}_results.zip",
        media_type="application/zip"
    )


@app.get("/jobs")
async def list_jobs(status: Optional[str] = None, limit: int = 20):
    """작업 목록 조회

    Args:
        status: 필터링할 상태 (queued, running, completed, failed)
        limit: 최대 반환 개수
    """
    jobs = list(_jobs.values())

    if status:
        try:
            filter_status = JobStatus(status)
            jobs = [j for j in jobs if j.status == filter_status]
        except ValueError:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid status. Valid values: {[s.value for s in JobStatus]}"
            )

    # 최신순 정렬
    jobs.sort(key=lambda x: x.created_at, reverse=True)
    jobs = jobs[:limit]

    return {
        "total": len(jobs),
        "jobs": [j.to_dict() for j in jobs]
    }


@app.delete("/jobs/{job_id}")
async def delete_job(job_id: str):
    """작업 삭제"""
    if job_id not in _jobs:
        raise HTTPException(status_code=404, detail="Job not found")

    job = _jobs[job_id]

    # 실행 중인 작업은 삭제 불가
    if job.status == JobStatus.RUNNING:
        raise HTTPException(
            status_code=400,
            detail="Cannot delete running job"
        )

    # 출력 디렉토리 정리
    if job.output_dir and Path(job.output_dir).exists():
        shutil.rmtree(job.output_dir, ignore_errors=True)

    del _jobs[job_id]

    return {"message": f"Job {job_id} deleted"}


if __name__ == "__main__":
    import uvicorn
    server_config = load_config().get('server', {})
    uvicorn.run(
        "src.server:app",
        host=server_config.get('host', '0.0.0.0'),
        port=server_config.get('port', 8080),
        reload=True
    )
