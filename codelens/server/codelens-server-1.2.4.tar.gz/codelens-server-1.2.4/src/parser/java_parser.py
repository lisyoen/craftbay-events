"""Java 소스코드 파서"""

import re
from dataclasses import dataclass, field
from typing import List, Optional
from pathlib import Path


@dataclass
class JavaElement:
    """Java 코드 요소"""
    type: str  # class, interface, enum, method, field
    name: str
    content: str
    start_line: int
    end_line: int
    modifiers: List[str] = field(default_factory=list)
    parent: Optional[str] = None


class JavaParser:
    """Java 소스코드 파서 - 정규식 기반"""
    
    def __init__(self):
        # 클래스/인터페이스/enum 패턴
        self.class_pattern = re.compile(
            r'((?:public|private|protected|abstract|final|static)\s+)*'
            r'(class|interface|enum)\s+'
            r'(\w+)'
            r'(?:\s+extends\s+[\w<>,\s]+)?'
            r'(?:\s+implements\s+[\w<>,\s]+)?\s*\{',
            re.MULTILINE
        )
        
        # 메서드 패턴
        self.method_pattern = re.compile(
            r'((?:public|private|protected|static|final|abstract|synchronized|native)\s+)*'
            r'(?:<[\w<>,\s]+>\s+)?'  # 제네릭
            r'([\w<>\[\],\s]+)\s+'  # 반환 타입
            r'(\w+)\s*'  # 메서드명
            r'\(([^)]*)\)\s*'  # 파라미터
            r'(?:throws\s+[\w<>,\s]+)?\s*'
            r'\{',
            re.MULTILINE
        )
    
    def parse_file(self, filepath: str) -> List[JavaElement]:
        """파일 파싱"""
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        return self.parse(content)
    
    def parse(self, content: str) -> List[JavaElement]:
        """Java 코드 파싱"""
        elements = []
        lines = content.split('\n')
        
        # 클래스/인터페이스/enum 찾기
        for match in self.class_pattern.finditer(content):
            modifiers = match.group(1).split() if match.group(1) else []
            element_type = match.group(2)
            name = match.group(3)
            start_pos = match.start()
            start_line = content[:start_pos].count('\n') + 1
            
            # 중괄호 매칭으로 끝 찾기
            end_pos = self._find_matching_brace(content, match.end() - 1)
            end_line = content[:end_pos].count('\n') + 1
            
            element_content = content[start_pos:end_pos + 1]
            
            elements.append(JavaElement(
                type=element_type,
                name=name,
                content=element_content,
                start_line=start_line,
                end_line=end_line,
                modifiers=modifiers
            ))
        
        # 클래스가 없으면 전체를 하나의 요소로
        if not elements:
            elements.append(JavaElement(
                type='file',
                name=Path(filepath).stem if 'filepath' in dir() else 'unknown',
                content=content,
                start_line=1,
                end_line=len(lines)
            ))
        
        return elements
    
    def _find_matching_brace(self, content: str, start: int) -> int:
        """중괄호 매칭 찾기"""
        count = 1
        i = start + 1
        in_string = False
        string_char = None
        
        while i < len(content) and count > 0:
            char = content[i]
            
            # 문자열 처리
            if char in '"\'':
                if not in_string:
                    in_string = True
                    string_char = char
                elif char == string_char and content[i-1] != '\\':
                    in_string = False
            
            if not in_string:
                if char == '{':
                    count += 1
                elif char == '}':
                    count -= 1
            
            i += 1
        
        return i - 1


class JavaChunker:
    """Java 코드를 청크로 분리"""
    
    def __init__(self, target_size_kb: int = 40, max_size_kb: int = 60):
        self.target_size = target_size_kb * 1024
        self.max_size = max_size_kb * 1024
        self.parser = JavaParser()
    
    def chunk_file(self, filepath: str) -> List[dict]:
        """파일을 청크로 분리"""
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        return self.chunk(content, filepath)
    
    def chunk(self, content: str, source: str = "unknown") -> List[dict]:
        """Java 코드를 청크로 분리"""
        elements = self.parser.parse(content)
        chunks = []
        
        for elem in elements:
            elem_size = len(elem.content.encode('utf-8'))
            
            if elem_size <= self.max_size:
                chunks.append({
                    'content': elem.content,
                    'type': elem.type,
                    'name': elem.name,
                    'source': source,
                    'start_line': elem.start_line,
                    'end_line': elem.end_line,
                    'size_kb': elem_size / 1024
                })
            else:
                # 큰 클래스는 메서드 단위로 분리
                sub_chunks = self._split_large_element(elem, source)
                chunks.extend(sub_chunks)
        
        return chunks
    
    def _split_large_element(self, elem: JavaElement, source: str) -> List[dict]:
        """큰 요소를 더 작은 청크로 분리"""
        chunks = []
        lines = elem.content.split('\n')
        
        current_chunk = []
        current_size = 0
        chunk_start = elem.start_line
        
        for i, line in enumerate(lines):
            line_size = len(line.encode('utf-8')) + 1
            
            if current_size + line_size > self.target_size and current_chunk:
                chunks.append({
                    'content': '\n'.join(current_chunk),
                    'type': 'partial',
                    'name': f"{elem.name}_part{len(chunks)+1}",
                    'source': source,
                    'start_line': chunk_start,
                    'end_line': elem.start_line + i - 1,
                    'size_kb': current_size / 1024
                })
                current_chunk = []
                current_size = 0
                chunk_start = elem.start_line + i
            
            current_chunk.append(line)
            current_size += line_size
        
        if current_chunk:
            chunks.append({
                'content': '\n'.join(current_chunk),
                'type': 'partial' if len(chunks) > 0 else elem.type,
                'name': f"{elem.name}_part{len(chunks)+1}" if len(chunks) > 0 else elem.name,
                'source': source,
                'start_line': chunk_start,
                'end_line': elem.end_line,
                'size_kb': current_size / 1024
            })
        
        return chunks
