"""HTML에서 JavaScript 코드를 추출하는 모듈"""

from dataclasses import dataclass
from typing import List, Optional
from bs4 import BeautifulSoup


@dataclass
class ScriptInfo:
    """추출된 스크립트 정보"""
    content: str
    script_type: Optional[str] = None
    src: Optional[str] = None
    line_number: int = 0


class HTMLScriptExtractor:
    """HTML 문서에서 <script> 태그를 추출하는 클래스"""

    def __init__(self, html_content: str = ""):
        self.html_content = html_content

    def extract(self) -> List[ScriptInfo]:
        """HTML에서 모든 스크립트 추출"""
        if not self.html_content:
            return []
        
        soup = BeautifulSoup(self.html_content, 'html.parser')
        scripts = []

        for i, script_tag in enumerate(soup.find_all('script')):
            # 외부 스크립트는 건너뜀
            if script_tag.get('src'):
                continue

            content = script_tag.string or ""
            if content.strip():
                scripts.append(ScriptInfo(
                    content=content,
                    script_type=script_tag.get('type'),
                    line_number=i
                ))

        return scripts

    def extract_from_file(self, filepath: str) -> List[ScriptInfo]:
        """파일에서 스크립트 추출"""
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            self.html_content = f.read()
        return self.extract()
