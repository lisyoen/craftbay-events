#!/bin/bash
set -e

echo "================================================"
echo "  CodeLens Server Install"
echo "================================================"
echo ""

# 기존 CodeLens 서버 종료
if pgrep -f "uvicorn.*codelens" > /dev/null 2>&1; then
    echo "[0/5] Stopping existing CodeLens server..."
    pkill -f "uvicorn.*codelens" || true
    sleep 2
fi

# 3002 포트 사용 중인 프로세스 종료
if lsof -i :3002 > /dev/null 2>&1; then
    echo "[0/5] Port 3002 in use, stopping..."
    fuser -k 3002/tcp 2>/dev/null || true
    sleep 2
fi

# Python 버전 확인
PYTHON_VERSION=$(python3 --version 2>&1 | cut -d' ' -f2 | cut -d'.' -f1,2)
REQUIRED_VERSION="3.10"

version_compare() {
    printf '%s\n%s\n' "$REQUIRED_VERSION" "$1" | sort -V | head -n1
}

if [ "$(version_compare "$PYTHON_VERSION")" != "$REQUIRED_VERSION" ]; then
    echo "[ERROR] Python 3.10+ required. Current: Python $PYTHON_VERSION"
    exit 1
fi

echo "[1/5] Creating virtual environment..."
python3 -m venv venv
source venv/bin/activate

echo "[2/5] Installing dependencies (offline)..."
if [ -d "wheels" ]; then
    pip install --no-index --find-links=wheels -r requirements.txt 2>/dev/null || pip install -r requirements.txt
else
    pip install -r requirements.txt
fi

echo "[3/5] Creating log directory..."
mkdir -p logs

echo "[4/5] Install complete!"
echo ""
echo "================================================"
echo "  Starting server..."
echo "================================================"

nohup ./run_server.sh > logs/server.log 2>&1 &
SERVER_PID=$!
sleep 2

if ps -p $SERVER_PID > /dev/null 2>&1; then
    PORT=$(sed -n '/^server:/,/^[a-zA-Z]/p' config/settings.yaml | grep "port:" | head -1 | awk '{print $2}')
    echo ""
    echo "[5/5] Server started! (PID: $SERVER_PID)"
    echo ""
    echo "  URL: http://0.0.0.0:${PORT:-3002}"
    echo "  Log: tail -f logs/server.log"
    echo "  Stop: kill $SERVER_PID"
    echo ""
else
    echo "[ERROR] Server failed to start. Check log:"
    cat logs/server.log
    exit 1
fi
