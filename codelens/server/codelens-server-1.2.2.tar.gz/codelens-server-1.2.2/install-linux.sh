#!/bin/bash
set -e

echo "================================================"
echo "  CodeLens Server 설치"
echo "================================================"
echo ""

# Python 버전 확인
PYTHON_VERSION=$(python3 --version 2>&1 | cut -d' ' -f2 | cut -d'.' -f1,2)
REQUIRED_VERSION="3.10"

version_compare() {
    printf '%s\n%s\n' "$REQUIRED_VERSION" "$1" | sort -V | head -n1
}

if [ "$(version_compare "$PYTHON_VERSION")" != "$REQUIRED_VERSION" ]; then
    echo "[오류] Python 3.10 이상이 필요합니다. 현재: Python $PYTHON_VERSION"
    exit 1
fi

echo "[1/5] 가상환경 생성 중..."
python3 -m venv venv
source venv/bin/activate

echo "[2/5] 의존성 설치 중 (오프라인)..."
if [ -d "wheels" ]; then
    pip install --no-index --find-links=wheels -r requirements.txt 2>/dev/null || pip install -r requirements.txt
else
    pip install -r requirements.txt
fi

echo "[3/5] 로그 디렉토리 생성..."
mkdir -p logs

echo "[4/5] 설치 완료!"
echo ""
echo "================================================"
echo "  서버 시작 중..."
echo "================================================"

# 서버 실행
nohup ./run_server.sh > logs/server.log 2>&1 &
SERVER_PID=$!
sleep 2

# 실행 확인
if ps -p $SERVER_PID > /dev/null 2>&1; then
    PORT=$(sed -n '/^server:/,/^[a-zA-Z]/p' config/settings.yaml | grep "port:" | head -1 | awk '{print $2}')
    echo ""
    echo "[5/5] 서버 실행 완료! (PID: $SERVER_PID)"
    echo ""
    echo "  URL: http://0.0.0.0:${PORT:-3002}"
    echo "  로그: tail -f logs/server.log"
    echo "  종료: kill $SERVER_PID"
    echo ""
else
    echo "[오류] 서버 실행 실패. 로그 확인:"
    cat logs/server.log
    exit 1
fi
