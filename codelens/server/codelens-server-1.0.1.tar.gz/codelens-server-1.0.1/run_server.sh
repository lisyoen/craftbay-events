#!/bin/bash
# CodeLens API Server 실행 스크립트

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 가상환경 활성화
if [ -d "venv" ]; then
    source venv/bin/activate
else
    echo "Error: venv not found. Run 'python -m venv venv && pip install -r requirements.txt' first."
    exit 1
fi

# 로그 디렉토리 생성
mkdir -p logs

# 기본 설정
HOST="${CODELENS_HOST:-0.0.0.0}"
PORT="${CODELENS_PORT:-8080}"
WORKERS="${CODELENS_WORKERS:-1}"
LOG_LEVEL="${CODELENS_LOG_LEVEL:-info}"

echo "Starting CodeLens Server..."
echo "  Host: $HOST"
echo "  Port: $PORT"
echo "  Workers: $WORKERS"
echo "  Log Level: $LOG_LEVEL"

# 서버 실행
exec uvicorn src.server:app \
    --host "$HOST" \
    --port "$PORT" \
    --workers "$WORKERS" \
    --log-level "$LOG_LEVEL"
