@echo off
echo ================================================
echo   CodeLens Client 설치
echo ================================================
echo.

REM Python 확인
python --version >nul 2>&1
if errorlevel 1 (
    echo [오류] Python이 설치되어 있지 않습니다.
    echo        python-3.11.9-amd64.exe를 먼저 설치하세요.
    pause
    exit /b 1
)

echo [1/2] 의존성 설치 중 (오프라인)...
pip install --no-index --find-links=wheels -r requirements.txt

echo [2/2] 설치 완료!
echo.
echo 사용법:
echo   1. config.yaml에서 server.url 설정
echo   2. python codelens.py analyze [파일경로]
echo.
pause
