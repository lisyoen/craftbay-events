#!/usr/bin/env python3
"""
CodeLens CLI Client
Python 기반 코드 분석 클라이언트
"""

import argparse
import json
import os
import sys
import time
from pathlib import Path
from typing import Optional, Dict, Any

try:
    import yaml
    import requests
    from rich.console import Console
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
    from rich.table import Table
    from rich.panel import Panel
except ImportError as e:
    print(f"필수 패키지가 설치되지 않았습니다: {e}")
    print("다음 명령으로 설치하세요: pip install -r requirements.txt")
    sys.exit(1)

__version__ = "1.0.0"

console = Console()


def load_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    """설정 파일 로드"""
    if config_path is None:
        # 스크립트와 같은 디렉토리의 config.yaml 찾기
        script_dir = Path(__file__).parent
        config_path = script_dir / "config.yaml"
    else:
        config_path = Path(config_path)

    if not config_path.exists():
        console.print(f"[red]설정 파일을 찾을 수 없습니다: {config_path}[/red]")
        console.print("[yellow]config.yaml.example을 config.yaml로 복사하고 설정하세요.[/yellow]")
        sys.exit(1)

    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def get_server_url(config: Dict[str, Any]) -> str:
    """서버 URL 반환"""
    return config.get('server', {}).get('url', 'http://localhost:8080')


def get_timeout(config: Dict[str, Any]) -> int:
    """타임아웃 반환"""
    return config.get('server', {}).get('timeout', 3600)


def get_output_dir(config: Dict[str, Any]) -> Path:
    """출력 디렉토리 반환"""
    output_dir = config.get('output', {}).get('dir', './codelens-output')
    path = Path(output_dir)
    path.mkdir(parents=True, exist_ok=True)
    return path


def cmd_analyze(args, config: Dict[str, Any]):
    """파일 분석 요청"""
    filepath = Path(args.filepath)

    if not filepath.exists():
        console.print(f"[red]파일을 찾을 수 없습니다: {filepath}[/red]")
        sys.exit(1)

    server_url = get_server_url(config)
    timeout = get_timeout(config)

    console.print(Panel(f"[bold]CodeLens 코드 분석[/bold]\n파일: {filepath}\n서버: {server_url}"))

    # 파일 읽기
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
    except UnicodeDecodeError:
        with open(filepath, 'r', encoding='cp949') as f:
            content = f.read()

    # 분석 요청
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True
    ) as progress:
        task = progress.add_task("서버에 분석 요청 중...", total=None)

        try:
            response = requests.post(
                f"{server_url}/api/v1/analyze",
                json={
                    "filename": filepath.name,
                    "content": content,
                    "language": filepath.suffix.lstrip('.') or "unknown"
                },
                timeout=30
            )
            response.raise_for_status()
            result = response.json()
        except requests.exceptions.ConnectionError:
            console.print(f"[red]서버에 연결할 수 없습니다: {server_url}[/red]")
            console.print("[yellow]config.yaml의 server.url 설정을 확인하세요.[/yellow]")
            sys.exit(1)
        except requests.exceptions.Timeout:
            console.print("[red]요청 시간이 초과되었습니다.[/red]")
            sys.exit(1)
        except requests.exceptions.HTTPError as e:
            console.print(f"[red]서버 오류: {e}[/red]")
            sys.exit(1)

    job_id = result.get('job_id')
    if not job_id:
        console.print("[red]작업 ID를 받지 못했습니다.[/red]")
        sys.exit(1)

    console.print(f"[green]분석 작업이 시작되었습니다.[/green]")
    console.print(f"작업 ID: [bold]{job_id}[/bold]")

    if args.wait:
        # 완료까지 대기
        console.print("\n분석 진행 중...")
        wait_for_completion(job_id, config)
    else:
        console.print(f"\n[yellow]상태 확인: python codelens.py status {job_id}[/yellow]")
        console.print(f"[yellow]결과 다운로드: python codelens.py download {job_id}[/yellow]")


def cmd_status(args, config: Dict[str, Any]):
    """작업 상태 확인"""
    job_id = args.job_id
    server_url = get_server_url(config)

    try:
        response = requests.get(
            f"{server_url}/api/v1/jobs/{job_id}",
            timeout=30
        )
        response.raise_for_status()
        result = response.json()
    except requests.exceptions.ConnectionError:
        console.print(f"[red]서버에 연결할 수 없습니다: {server_url}[/red]")
        sys.exit(1)
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 404:
            console.print(f"[red]작업을 찾을 수 없습니다: {job_id}[/red]")
        else:
            console.print(f"[red]서버 오류: {e}[/red]")
        sys.exit(1)

    # 상태 표시
    table = Table(title=f"작업 상태: {job_id}")
    table.add_column("항목", style="cyan")
    table.add_column("값", style="white")

    status = result.get('status', 'unknown')
    status_color = {
        'pending': 'yellow',
        'processing': 'blue',
        'completed': 'green',
        'failed': 'red'
    }.get(status, 'white')

    table.add_row("상태", f"[{status_color}]{status}[/{status_color}]")
    table.add_row("파일", result.get('filename', 'N/A'))
    table.add_row("생성 시간", result.get('created_at', 'N/A'))

    if result.get('progress'):
        table.add_row("진행률", f"{result['progress']}%")

    if result.get('error'):
        table.add_row("오류", f"[red]{result['error']}[/red]")

    console.print(table)

    if status == 'completed':
        console.print(f"\n[green]분석이 완료되었습니다![/green]")
        console.print(f"결과 다운로드: python codelens.py download {job_id}")


def cmd_download(args, config: Dict[str, Any]):
    """결과 다운로드"""
    job_id = args.job_id
    server_url = get_server_url(config)
    output_dir = get_output_dir(config)

    # 먼저 상태 확인
    try:
        response = requests.get(
            f"{server_url}/api/v1/jobs/{job_id}",
            timeout=30
        )
        response.raise_for_status()
        status_result = response.json()
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 404:
            console.print(f"[red]작업을 찾을 수 없습니다: {job_id}[/red]")
        else:
            console.print(f"[red]서버 오류: {e}[/red]")
        sys.exit(1)

    if status_result.get('status') != 'completed':
        console.print(f"[yellow]작업이 아직 완료되지 않았습니다. 상태: {status_result.get('status')}[/yellow]")
        sys.exit(1)

    # 결과 다운로드
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        transient=True
    ) as progress:
        task = progress.add_task("결과 다운로드 중...", total=100)

        try:
            response = requests.get(
                f"{server_url}/api/v1/jobs/{job_id}/result",
                timeout=300,
                stream=True
            )
            response.raise_for_status()

            # 파일명 결정
            filename = status_result.get('filename', 'result')
            output_file = output_dir / f"{filename}_{job_id}_analysis.md"

            # 결과 저장
            total_size = int(response.headers.get('content-length', 0))
            downloaded = 0

            with open(output_file, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        progress.update(task, completed=int(downloaded / total_size * 100))

            progress.update(task, completed=100)

        except requests.exceptions.HTTPError as e:
            console.print(f"[red]다운로드 실패: {e}[/red]")
            sys.exit(1)

    console.print(f"[green]다운로드 완료![/green]")
    console.print(f"저장 위치: {output_file}")

    # 결과 미리보기
    if args.preview:
        console.print("\n[bold]분석 결과 미리보기:[/bold]")
        with open(output_file, 'r', encoding='utf-8') as f:
            preview = f.read(2000)
            if len(preview) == 2000:
                preview += "\n\n... (계속)"
            console.print(Panel(preview))


def cmd_config(args, config: Dict[str, Any]):
    """설정 관리"""
    if args.config_action == 'show':
        # 설정 표시
        table = Table(title="현재 설정")
        table.add_column("키", style="cyan")
        table.add_column("값", style="white")

        table.add_row("server.url", config.get('server', {}).get('url', 'N/A'))
        table.add_row("server.timeout", str(config.get('server', {}).get('timeout', 'N/A')))
        table.add_row("output.dir", config.get('output', {}).get('dir', 'N/A'))
        table.add_row("llm.enabled", str(config.get('llm', {}).get('enabled', False)))

        if config.get('llm', {}).get('enabled'):
            table.add_row("llm.base_url", config.get('llm', {}).get('base_url', 'N/A'))
            table.add_row("llm.model", config.get('llm', {}).get('model', 'N/A'))

        console.print(table)

    elif args.config_action == 'test':
        # 서버 연결 테스트
        server_url = get_server_url(config)
        console.print(f"서버 연결 테스트: {server_url}")

        try:
            response = requests.get(f"{server_url}/health", timeout=10)
            if response.status_code == 200:
                console.print("[green]서버 연결 성공![/green]")
            else:
                console.print(f"[yellow]서버 응답: {response.status_code}[/yellow]")
        except requests.exceptions.ConnectionError:
            console.print("[red]서버에 연결할 수 없습니다.[/red]")
        except requests.exceptions.Timeout:
            console.print("[red]연결 시간 초과[/red]")


def cmd_list(args, config: Dict[str, Any]):
    """작업 목록 조회"""
    server_url = get_server_url(config)

    try:
        response = requests.get(
            f"{server_url}/api/v1/jobs",
            params={'limit': args.limit},
            timeout=30
        )
        response.raise_for_status()
        result = response.json()
    except requests.exceptions.ConnectionError:
        console.print(f"[red]서버에 연결할 수 없습니다: {server_url}[/red]")
        sys.exit(1)
    except requests.exceptions.HTTPError as e:
        console.print(f"[red]서버 오류: {e}[/red]")
        sys.exit(1)

    jobs = result.get('jobs', [])

    if not jobs:
        console.print("[yellow]작업이 없습니다.[/yellow]")
        return

    table = Table(title="최근 작업 목록")
    table.add_column("작업 ID", style="cyan", no_wrap=True)
    table.add_column("파일", style="white")
    table.add_column("상태", style="white")
    table.add_column("생성 시간", style="white")

    for job in jobs:
        status = job.get('status', 'unknown')
        status_color = {
            'pending': 'yellow',
            'processing': 'blue',
            'completed': 'green',
            'failed': 'red'
        }.get(status, 'white')

        table.add_row(
            job.get('job_id', 'N/A')[:12] + "...",
            job.get('filename', 'N/A'),
            f"[{status_color}]{status}[/{status_color}]",
            job.get('created_at', 'N/A')
        )

    console.print(table)


def wait_for_completion(job_id: str, config: Dict[str, Any]):
    """작업 완료 대기"""
    server_url = get_server_url(config)
    timeout = get_timeout(config)
    start_time = time.time()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
    ) as progress:
        task = progress.add_task("분석 진행 중...", total=100)

        while True:
            elapsed = time.time() - start_time
            if elapsed > timeout:
                console.print("[red]타임아웃: 분석 시간이 초과되었습니다.[/red]")
                sys.exit(1)

            try:
                response = requests.get(
                    f"{server_url}/api/v1/jobs/{job_id}",
                    timeout=30
                )
                response.raise_for_status()
                result = response.json()
            except Exception as e:
                console.print(f"[red]상태 확인 실패: {e}[/red]")
                time.sleep(5)
                continue

            status = result.get('status')
            job_progress = result.get('progress', 0)
            progress.update(task, completed=job_progress)

            if status == 'completed':
                progress.update(task, completed=100)
                console.print("\n[green]분석이 완료되었습니다![/green]")
                console.print(f"결과 다운로드: python codelens.py download {job_id}")
                break
            elif status == 'failed':
                console.print(f"\n[red]분석 실패: {result.get('error', '알 수 없는 오류')}[/red]")
                sys.exit(1)

            time.sleep(3)


def main():
    parser = argparse.ArgumentParser(
        prog='codelens',
        description='CodeLens - AI 기반 코드 분석 클라이언트',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
예제:
  python codelens.py analyze main.py          파일 분석 요청
  python codelens.py analyze main.py --wait   분석 완료까지 대기
  python codelens.py status <job_id>          작업 상태 확인
  python codelens.py download <job_id>        결과 다운로드
  python codelens.py list                     최근 작업 목록
  python codelens.py config show              설정 확인
  python codelens.py config test              서버 연결 테스트
"""
    )

    parser.add_argument(
        '-v', '--version',
        action='version',
        version=f'%(prog)s {__version__}'
    )

    parser.add_argument(
        '-c', '--config',
        help='설정 파일 경로 (기본: config.yaml)',
        metavar='FILE'
    )

    subparsers = parser.add_subparsers(dest='command', help='명령어')

    # analyze 명령
    analyze_parser = subparsers.add_parser('analyze', help='파일 분석 요청')
    analyze_parser.add_argument('filepath', help='분석할 파일 경로')
    analyze_parser.add_argument(
        '-w', '--wait',
        action='store_true',
        help='분석 완료까지 대기'
    )

    # status 명령
    status_parser = subparsers.add_parser('status', help='작업 상태 확인')
    status_parser.add_argument('job_id', help='작업 ID')

    # download 명령
    download_parser = subparsers.add_parser('download', help='결과 다운로드')
    download_parser.add_argument('job_id', help='작업 ID')
    download_parser.add_argument(
        '-p', '--preview',
        action='store_true',
        help='다운로드 후 미리보기'
    )

    # list 명령
    list_parser = subparsers.add_parser('list', help='작업 목록 조회')
    list_parser.add_argument(
        '-n', '--limit',
        type=int,
        default=10,
        help='표시할 작업 수 (기본: 10)'
    )

    # config 명령
    config_parser = subparsers.add_parser('config', help='설정 관리')
    config_parser.add_argument(
        'config_action',
        choices=['show', 'test'],
        help='show: 설정 표시, test: 서버 연결 테스트'
    )

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    # 설정 로드
    config = load_config(args.config)

    # 명령 실행
    commands = {
        'analyze': cmd_analyze,
        'status': cmd_status,
        'download': cmd_download,
        'list': cmd_list,
        'config': cmd_config,
    }

    cmd_func = commands.get(args.command)
    if cmd_func:
        cmd_func(args, config)
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
