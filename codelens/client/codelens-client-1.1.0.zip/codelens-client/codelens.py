#!/usr/bin/env python3
"""
CodeLens Client - 대용량 소스코드 분석 클라이언트
"""

import argparse
import sys
import os
import json
import time
from pathlib import Path

import requests
import yaml
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()

def load_config():
    """설정 파일 로드"""
    config_path = Path(__file__).parent / "config.yaml"
    if not config_path.exists():
        console.print("[red]오류: config.yaml 파일이 없습니다.[/red]")
        sys.exit(1)
    
    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def select_file():
    """파일 선택 팝업"""
    try:
        import tkinter as tk
        from tkinter import filedialog
        
        root = tk.Tk()
        root.withdraw()  # 메인 윈도우 숨김
        root.attributes('-topmost', True)  # 최상위로
        
        file_path = filedialog.askopenfilename(
            title="분석할 파일 선택",
            filetypes=[
                ("소스 파일", "*.java *.js *.jsx *.ts *.tsx *.html *.htm"),
                ("Java", "*.java"),
                ("JavaScript", "*.js *.jsx"),
                ("TypeScript", "*.ts *.tsx"),
                ("HTML", "*.html *.htm"),
                ("모든 파일", "*.*")
            ]
        )
        
        root.destroy()
        return file_path if file_path else None
        
    except ImportError:
        console.print("[yellow]GUI를 사용할 수 없습니다. 파일 경로를 직접 입력하세요.[/yellow]")
        return input("파일 경로: ").strip()

def analyze(filepath: str, config: dict):
    """파일 분석 요청"""
    server_url = config.get('server', {}).get('url', 'http://localhost:8080')
    timeout = config.get('server', {}).get('timeout', 3600)
    
    if not os.path.exists(filepath):
        console.print(f"[red]오류: 파일이 존재하지 않습니다: {filepath}[/red]")
        return
    
    console.print(f"[cyan]분석 대상:[/cyan] {filepath}")
    console.print(f"[cyan]서버:[/cyan] {server_url}")
    console.print()
    
    # 파일 업로드 및 분석 요청
    try:
        with open(filepath, 'rb') as f:
            files = {'file': (os.path.basename(filepath), f)}
            
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console
            ) as progress:
                task = progress.add_task("파일 업로드 중...", total=None)
                
                response = requests.post(
                    f"{server_url}/api/analyze",
                    files=files,
                    timeout=30
                )
                
                progress.update(task, description="응답 처리 중...")
        
        if response.status_code == 200:
            result = response.json()
            job_id = result.get('job_id')
            console.print(f"[green]분석 작업 등록 완료![/green]")
            console.print(f"[cyan]Job ID:[/cyan] {job_id}")
            console.print()
            console.print(f"상태 확인: python codelens.py status {job_id}")
            console.print(f"결과 다운로드: python codelens.py download {job_id}")
        else:
            console.print(f"[red]오류: {response.status_code}[/red]")
            console.print(response.text)
            
    except requests.exceptions.ConnectionError:
        console.print(f"[red]오류: 서버에 연결할 수 없습니다 ({server_url})[/red]")
    except Exception as e:
        console.print(f"[red]오류: {e}[/red]")

def status(job_id: str, config: dict):
    """작업 상태 확인"""
    server_url = config.get('server', {}).get('url', 'http://localhost:8080')
    
    try:
        response = requests.get(f"{server_url}/api/jobs/{job_id}")
        if response.status_code == 200:
            result = response.json()
            console.print(f"[cyan]Job ID:[/cyan] {job_id}")
            console.print(f"[cyan]상태:[/cyan] {result.get('status')}")
            console.print(f"[cyan]진행률:[/cyan] {result.get('progress', 0)}%")
            if result.get('error'):
                console.print(f"[red]오류:[/red] {result.get('error')}")
        else:
            console.print(f"[red]오류: {response.status_code}[/red]")
    except requests.exceptions.ConnectionError:
        console.print(f"[red]오류: 서버에 연결할 수 없습니다 ({server_url})[/red]")

def download(job_id: str, config: dict):
    """결과 다운로드"""
    server_url = config.get('server', {}).get('url', 'http://localhost:8080')
    output_dir = config.get('output', {}).get('dir', './codelens-output')
    
    try:
        response = requests.get(f"{server_url}/api/jobs/{job_id}/result")
        if response.status_code == 200:
            os.makedirs(output_dir, exist_ok=True)
            output_path = os.path.join(output_dir, f"{job_id}")
            os.makedirs(output_path, exist_ok=True)
            
            result = response.json()
            
            # 보고서 저장
            if result.get('report'):
                report_path = os.path.join(output_path, 'report.md')
                with open(report_path, 'w', encoding='utf-8') as f:
                    f.write(result['report'])
                console.print(f"[green]보고서 저장:[/green] {report_path}")
            
            # 리팩토링 가이드 저장
            if result.get('refactor'):
                refactor_path = os.path.join(output_path, 'refactor.md')
                with open(refactor_path, 'w', encoding='utf-8') as f:
                    f.write(result['refactor'])
                console.print(f"[green]리팩토링 가이드:[/green] {refactor_path}")
                
        else:
            console.print(f"[red]오류: {response.status_code}[/red]")
    except requests.exceptions.ConnectionError:
        console.print(f"[red]오류: 서버에 연결할 수 없습니다 ({server_url})[/red]")

def main():
    config = load_config()
    
    parser = argparse.ArgumentParser(
        description='CodeLens - 대용량 소스코드 분석 클라이언트',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    subparsers = parser.add_subparsers(dest='command', help='명령어')
    
    # analyze 명령
    analyze_parser = subparsers.add_parser('analyze', help='파일 분석')
    analyze_parser.add_argument('filepath', nargs='?', help='분석할 파일 경로 (생략시 파일 선택 팝업)')
    
    # status 명령
    status_parser = subparsers.add_parser('status', help='작업 상태 확인')
    status_parser.add_argument('job_id', help='작업 ID')
    
    # download 명령
    download_parser = subparsers.add_parser('download', help='결과 다운로드')
    download_parser.add_argument('job_id', help='작업 ID')
    
    # config 명령
    config_parser = subparsers.add_parser('config', help='설정 확인')
    
    args = parser.parse_args()
    
    # 명령어 없이 실행하면 파일 선택 팝업
    if args.command is None:
        console.print("[cyan]CodeLens Client[/cyan]")
        console.print()
        filepath = select_file()
        if filepath:
            analyze(filepath, config)
        else:
            console.print("[yellow]파일이 선택되지 않았습니다.[/yellow]")
        return
    
    if args.command == 'analyze':
        if args.filepath:
            analyze(args.filepath, config)
        else:
            filepath = select_file()
            if filepath:
                analyze(filepath, config)
            else:
                console.print("[yellow]파일이 선택되지 않았습니다.[/yellow]")
    
    elif args.command == 'status':
        status(args.job_id, config)
    
    elif args.command == 'download':
        download(args.job_id, config)
    
    elif args.command == 'config':
        console.print("[cyan]현재 설정:[/cyan]")
        console.print(f"  서버: {config.get('server', {}).get('url')}")
        console.print(f"  출력 디렉토리: {config.get('output', {}).get('dir')}")

if __name__ == '__main__':
    main()
