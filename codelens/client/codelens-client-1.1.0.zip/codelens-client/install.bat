@echo off
chcp 65001 > nul
echo ================================================
echo   CodeLens Client 설치
echo ================================================
echo.

REM Python 확인
python --version >nul 2>&1
if errorlevel 1 (
    echo [오류] Python이 설치되어 있지 않습니다.
    pause
    exit /b 1
)

echo [1/2] 의존성 설치 중...
pip install --no-index --find-links=wheels requests pyyaml rich

echo.
echo [2/2] 설치 완료!
echo.
echo ================================================
echo   분석할 파일을 선택하세요
echo ================================================
echo.

python codelens.py
pause
