@echo off
chcp 65001 >nul
echo ========================================
echo   CodeLens 클라이언트 설치
echo ========================================
echo.

REM Python 확인
python --version >nul 2>&1
if errorlevel 1 (
    echo [오류] Python이 설치되어 있지 않습니다.
    echo.
    echo Python 3.8 이상을 설치하세요:
    echo https://www.python.org/downloads/
    echo.
    echo 설치 시 "Add Python to PATH" 옵션을 체크하세요.
    echo.
    pause
    exit /b 1
)

echo Python 버전:
python --version
echo.

REM pip 업그레이드
echo pip 업그레이드 중...
python -m pip install --upgrade pip --quiet

REM 의존성 설치
echo.
echo 의존성 패키지 설치 중...
pip install -r requirements.txt --user --quiet

if errorlevel 1 (
    echo.
    echo [오류] 패키지 설치에 실패했습니다.
    echo 네트워크 연결을 확인하고 다시 시도하세요.
    pause
    exit /b 1
)

echo.
echo ========================================
echo   설치 완료!
echo ========================================
echo.
echo 다음 단계:
echo 1. config.yaml 파일을 열어 서버 주소를 설정하세요
echo 2. 사용법: python codelens.py --help
echo.
echo 예시:
echo   python codelens.py analyze main.py
echo   python codelens.py config test
echo.
pause
