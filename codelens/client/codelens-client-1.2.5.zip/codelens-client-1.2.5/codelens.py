#!/usr/bin/env python3
"""CodeLens Client - 대용량 소스코드 분석 클라이언트"""

import argparse
import sys
import os
import time
from pathlib import Path

import requests
import yaml
from rich.console import Console
from rich.live import Live
from rich.table import Table

console = Console()

def load_config():
    config_path = Path(__file__).parent / "config.yaml"
    if not config_path.exists():
        console.print("[red]Error: config.yaml not found[/red]")
        sys.exit(1)
    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def select_file():
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        root.attributes('-topmost', True)
        file_path = filedialog.askopenfilename(
            title="Select file to analyze",
            filetypes=[
                ("Source files", "*.java *.js *.jsx *.ts *.tsx *.html *.htm"),
                ("Java", "*.java"),
                ("JavaScript", "*.js *.jsx"),
                ("TypeScript", "*.ts *.tsx"),
                ("HTML", "*.html *.htm"),
                ("All files", "*.*")
            ]
        )
        root.destroy()
        return file_path if file_path else None
    except ImportError:
        return input("File path: ").strip()

def make_status_table(job_id: str, data: dict) -> Table:
    table = Table(show_header=False, box=None)
    table.add_column("Key", style="cyan")
    table.add_column("Value")
    table.add_row("Job ID", job_id)
    table.add_row("Status", f"[green]{data.get('status')}[/green]" if data.get('status') == 'completed' else f"[yellow]{data.get('status')}[/yellow]")
    table.add_row("Phase", data.get('phase', ''))
    table.add_row("Progress", f"{data.get('progress', 0) * 100:.1f}%")
    table.add_row("Message", data.get('message', ''))
    if data.get('error'):
        table.add_row("Error", f"[red]{data.get('error')}[/red]")
    return table

def watch_status(job_id: str, config: dict):
    """5초마다 상태 업데이트"""
    server_url = config.get('server', {}).get('url', 'http://localhost:3002').rstrip('/')
    
    with Live(console=console, refresh_per_second=1) as live:
        while True:
            try:
                response = requests.get(f"{server_url}/status/{job_id}", timeout=600)
                if response.status_code == 200:
                    data = response.json()
                    live.update(make_status_table(job_id, data))
                    
                    if data.get('status') in ['completed', 'failed']:
                        break
                else:
                    live.update(f"[red]Error: {response.status_code}[/red]")
                    break
            except requests.exceptions.ConnectionError:
                live.update(f"[red]Connection error[/red]")
                break
            
            time.sleep(5)
    
    console.print()
    if data.get('status') == 'completed':
        console.print("[green]Analysis completed![/green]")
        console.print(f"Download: python codelens.py download {job_id}")
    elif data.get('status') == 'failed':
        console.print(f"[red]Analysis failed: {data.get('error')}[/red]")

def analyze(filepath: str, config: dict):
    server_url = config.get('server', {}).get('url', 'http://localhost:3002').rstrip('/')
    
    if not os.path.exists(filepath):
        console.print(f"[red]Error: File not found: {filepath}[/red]")
        return
    
    console.print(f"[cyan]File:[/cyan] {filepath}")
    console.print(f"[cyan]Server:[/cyan] {server_url}")
    console.print()
    
    try:
        with open(filepath, 'rb') as f:
            files = {'file': (os.path.basename(filepath), f)}
            console.print("Uploading...")
            response = requests.post(f"{server_url}/analyze", files=files, timeout=1200)
        
        if response.status_code in [200, 202]:
            result = response.json()
            job_id = result.get('job_id')
            console.print(f"[green]Job registered![/green]")
            console.print()
            watch_status(job_id, config)
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
            console.print(response.text)
            
    except requests.exceptions.ConnectionError:
        console.print(f"[red]Error: Cannot connect to server ({server_url})[/red]")

def status(job_id: str, config: dict):
    server_url = config.get('server', {}).get('url', 'http://localhost:3002').rstrip('/')
    try:
        response = requests.get(f"{server_url}/status/{job_id}")
        if response.status_code == 200:
            data = response.json()
            console.print(make_status_table(job_id, data))
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
    except requests.exceptions.ConnectionError:
        console.print(f"[red]Error: Cannot connect to server ({server_url})[/red]")

def download(job_id: str, config: dict):
    server_url = config.get('server', {}).get('url', 'http://localhost:3002').rstrip('/')
    output_dir = config.get('output', {}).get('dir', './codelens-output')
    
    try:
        response = requests.get(f"{server_url}/result/{job_id}")
        if response.status_code == 200:
            os.makedirs(output_dir, exist_ok=True)
            output_path = os.path.join(output_dir, job_id)
            os.makedirs(output_path, exist_ok=True)
            
            result = response.json()
            for key, value in result.items():
                if isinstance(value, str) and len(value) > 100:
                    file_path = os.path.join(output_path, f'{key}.md')
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(value)
                    console.print(f"[green]Saved:[/green] {file_path}")
            
            console.print(f"\n[cyan]Output directory:[/cyan] {output_path}")
        else:
            console.print(f"[red]Error: {response.status_code}[/red]")
    except requests.exceptions.ConnectionError:
        console.print(f"[red]Error: Cannot connect to server ({server_url})[/red]")

def run_interactive(config: dict):
    console.print("[cyan]CodeLens Client[/cyan]")
    console.print()
    filepath = select_file()
    if filepath:
        analyze(filepath, config)
    else:
        console.print("[yellow]No file selected[/yellow]")

def main():
    config = load_config()
    parser = argparse.ArgumentParser(description='CodeLens Client')
    subparsers = parser.add_subparsers(dest='command')
    
    subparsers.add_parser('run', help='Open file picker')
    
    analyze_p = subparsers.add_parser('analyze', help='Analyze file')
    analyze_p.add_argument('filepath', nargs='?')
    
    status_p = subparsers.add_parser('status', help='Check job status')
    status_p.add_argument('job_id')
    
    download_p = subparsers.add_parser('download', help='Download results')
    download_p.add_argument('job_id')
    
    subparsers.add_parser('config', help='Show config')
    
    args = parser.parse_args()
    
    if args.command is None or args.command == 'run':
        run_interactive(config)
    elif args.command == 'analyze':
        if args.filepath:
            analyze(args.filepath, config)
        else:
            run_interactive(config)
    elif args.command == 'status':
        status(args.job_id, config)
    elif args.command == 'download':
        download(args.job_id, config)
    elif args.command == 'config':
        console.print(f"[cyan]Server:[/cyan] {config.get('server', {}).get('url')}")
        console.print(f"[cyan]Output:[/cyan] {config.get('output', {}).get('dir')}")

if __name__ == '__main__':
    main()
