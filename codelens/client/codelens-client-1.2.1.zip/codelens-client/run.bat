@echo off
chcp 65001 > nul
python codelens.py run
pause
