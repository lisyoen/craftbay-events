@echo off
chcp 65001 > nul
echo ================================================
echo   CodeLens Client 설치
echo ================================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [오류] Python이 설치되어 있지 않습니다.
    pause
    exit /b 1
)

echo 의존성 설치 중...
pip install --no-index --find-links=wheels requests pyyaml rich

echo.
echo ================================================
echo   설치 완료!
echo ================================================
echo.
echo 실행 방법:
echo   run.bat        - 파일 선택 팝업
echo   python codelens.py analyze [파일경로]
echo.
pause
