#!/bin/bash
echo "========================================"
echo "  CodeLens 클라이언트 설치"
echo "========================================"
echo

# Python 확인
if ! command -v python3 &> /dev/null; then
    echo "[오류] Python3이 설치되어 있지 않습니다."
    echo
    echo "Ubuntu/Debian:"
    echo "  sudo apt install python3 python3-pip"
    echo
    echo "CentOS/RHEL:"
    echo "  sudo yum install python3 python3-pip"
    echo
    echo "macOS:"
    echo "  brew install python3"
    echo
    exit 1
fi

echo "Python 버전:"
python3 --version
echo

# pip 업그레이드
echo "pip 업그레이드 중..."
python3 -m pip install --upgrade pip --quiet 2>/dev/null || true

# 의존성 설치
echo
echo "의존성 패키지 설치 중..."
pip3 install -r requirements.txt --user --quiet

if [ $? -ne 0 ]; then
    echo
    echo "[오류] 패키지 설치에 실패했습니다."
    echo "네트워크 연결을 확인하고 다시 시도하세요."
    exit 1
fi

# 실행 권한 부여
chmod +x codelens.py

echo
echo "========================================"
echo "  설치 완료!"
echo "========================================"
echo
echo "다음 단계:"
echo "1. config.yaml 파일을 열어 서버 주소를 설정하세요"
echo "2. 사용법: python3 codelens.py --help"
echo
echo "예시:"
echo "  python3 codelens.py analyze main.py"
echo "  python3 codelens.py config test"
echo
