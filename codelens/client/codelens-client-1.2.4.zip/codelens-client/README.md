# CodeLens Python 클라이언트

AI 기반 코드 분석 도구의 Python 클라이언트입니다.

## 요구사항

- Python 3.8 이상
- pip (Python 패키지 관리자)

## 설치

### Windows

```cmd
install.bat
```

### Linux / macOS

```bash
chmod +x install.sh
./install.sh
```

### 수동 설치

```bash
pip install -r requirements.txt
```

## 설정

`config.yaml` 파일을 편집하여 서버 주소를 설정합니다:

```yaml
server:
  url: http://10.60.1.41:8080    # CodeLens 서버 주소
  timeout: 3600                   # 타임아웃 (초)

output:
  dir: ./codelens-output          # 결과 저장 경로
```

## 사용법

### 파일 분석

```bash
# 분석 요청
python codelens.py analyze main.py

# 분석 완료까지 대기
python codelens.py analyze main.py --wait
```

### 작업 상태 확인

```bash
python codelens.py status <job_id>
```

### 결과 다운로드

```bash
# 다운로드
python codelens.py download <job_id>

# 다운로드 후 미리보기
python codelens.py download <job_id> --preview
```

### 작업 목록 조회

```bash
# 최근 10개 작업
python codelens.py list

# 최근 20개 작업
python codelens.py list -n 20
```

### 설정 관리

```bash
# 현재 설정 확인
python codelens.py config show

# 서버 연결 테스트
python codelens.py config test
```

## 명령어 요약

| 명령어 | 설명 |
|--------|------|
| `analyze <file>` | 파일 분석 요청 |
| `status <job_id>` | 작업 상태 확인 |
| `download <job_id>` | 결과 다운로드 |
| `list` | 작업 목록 조회 |
| `config show` | 설정 확인 |
| `config test` | 서버 연결 테스트 |

## 옵션

| 옵션 | 설명 |
|------|------|
| `-c, --config <file>` | 설정 파일 경로 지정 |
| `-v, --version` | 버전 표시 |
| `-h, --help` | 도움말 표시 |

### analyze 옵션

| 옵션 | 설명 |
|------|------|
| `-w, --wait` | 분석 완료까지 대기 |

### download 옵션

| 옵션 | 설명 |
|------|------|
| `-p, --preview` | 다운로드 후 미리보기 |

### list 옵션

| 옵션 | 설명 |
|------|------|
| `-n, --limit <N>` | 표시할 작업 수 (기본: 10) |

## 문제 해결

### "서버에 연결할 수 없습니다" 오류

1. `config.yaml`의 `server.url` 설정을 확인하세요
2. 서버가 실행 중인지 확인하세요
3. 방화벽 설정을 확인하세요

### "필수 패키지가 설치되지 않았습니다" 오류

```bash
pip install -r requirements.txt
```

### Windows에서 한글이 깨지는 경우

명령 프롬프트에서 다음 명령을 실행하세요:
```cmd
chcp 65001
```

## 라이선스

내부 사용 전용
