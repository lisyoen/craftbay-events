@echo off
python codelens.py run
pause
