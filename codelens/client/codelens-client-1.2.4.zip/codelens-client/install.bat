@echo off
echo ================================================
echo   CodeLens Client Install
echo ================================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found.
    pause
    exit /b 1
)

echo Installing dependencies...
pip install --no-index --find-links=wheels requests pyyaml rich

echo.
echo ================================================
echo   Install Complete!
echo ================================================
echo.
echo Usage:
echo   run.bat                    - Open file picker
echo   python codelens.py analyze [filepath]
echo.
pause
