// RTunnel Browser Extension - Popup Script

async function updateStatus() {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'getStatus' });
    const statusEl = document.getElementById('status');

    if (response.status === 'connected') {
      statusEl.textContent = 'Connected';
      statusEl.className = 'status connected';
    } else {
      statusEl.textContent = 'Disconnected';
      statusEl.className = 'status disconnected';
    }

    document.getElementById('hostname').textContent = response.clientId?.slice(0, 8) || '-';
  } catch (e) {
    console.error('Status check failed:', e);
  }
}

// 상태 업데이트
updateStatus();
document.getElementById('server').textContent = 'rtunnel.craftbay.io';

// 상태 변경 리스너
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'status') {
    updateStatus();
  }
});
