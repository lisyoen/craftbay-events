// RTunnel Browser Extension - Background Service Worker
// v1.3.11 - iframe selectAll/insertText 지원

const SERVER_URL = 'wss://rtunnel-api.craftbay.io/ws';
const VERSION = '1.3.11';
let ws = null;
let clientId = null;
let reconnectTimer = null;

async function getHostname() {
  const result = await chrome.storage.local.get(['hostname']);
  return result.hostname || navigator.userAgentData?.platform || navigator.platform || 'Unknown';
}

function getBrowser() {
  const brands = navigator.userAgentData?.brands || [];
  for (const brand of brands) {
    if (brand.brand.includes('Edge')) return 'Edge';
    if (brand.brand.includes('Chrome')) return 'Chrome';
  }
  return 'Browser';
}

function safeSend(data) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(data));
    return true;
  }
  return false;
}

async function connect() {
  if (ws) {
    if (ws.readyState === WebSocket.OPEN) return;
    if (ws.readyState === WebSocket.CONNECTING) return;
  }

  try {
    const hostname = await getHostname();
    const browser = getBrowser();
    
    ws = new WebSocket(SERVER_URL);

    ws.onopen = () => {
      console.log('[RTunnel] Connected');
      setTimeout(() => {
        safeSend({
          type: 'browser_connect',
          hostname: hostname,
          browser: browser,
          version: VERSION
        });
      }, 100);
    };

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        handleMessage(msg);
      } catch (e) {
        console.error('[RTunnel] Parse error:', e);
      }
    };

    ws.onclose = () => {
      console.log('[RTunnel] Disconnected');
      ws = null;
      broadcastStatus('disconnected');
      scheduleReconnect();
    };

    ws.onerror = (error) => {
      console.error('[RTunnel] Error:', error);
    };

  } catch (e) {
    console.error('[RTunnel] Connection failed:', e);
    scheduleReconnect();
  }
}

function scheduleReconnect() {
  if (reconnectTimer) clearTimeout(reconnectTimer);
  reconnectTimer = setTimeout(connect, 5000);
}

async function handleMessage(msg) {
  switch (msg.type) {
    case 'welcome':
      clientId = msg.clientId;
      console.log('[RTunnel] Welcome ID:', clientId);
      break;
      
    case 'connected':
      clientId = msg.clientId;
      console.log('[RTunnel] Browser registered, ID:', clientId);
      if (msg.hostnameHint) {
        chrome.storage.local.set({ hostname: msg.hostnameHint });
        console.log('[RTunnel] Hostname hint saved:', msg.hostnameHint);
      }
      broadcastStatus('connected');
      break;
      
    case 'ping':
      safeSend({ type: 'pong', timestamp: Date.now() });
      break;
      
    case 'browser_command':
      console.log('[RTunnel] Command:', msg.action);
      try {
        const result = await executeCommand(msg.action, msg.params || {});
        safeSend({
          type: 'browser_response',
          requestId: msg.requestId,
          success: true,
          result: result
        });
      } catch (e) {
        console.error('[RTunnel] Command error:', e);
        safeSend({
          type: 'browser_response',
          requestId: msg.requestId,
          success: false,
          error: e.message
        });
      }
      break;
      
    case 'reload':
      console.log('[RTunnel] Reload requested');
      chrome.runtime.reload();
      break;
  }
}

async function executeCommand(action, params) {
  switch (action) {
    case 'listTabs': {
      const tabs = await chrome.tabs.query({});
      return tabs.map(t => ({ id: t.id, url: t.url, title: t.title, active: t.active }));
    }
    
    case 'openTab': {
      const tab = await chrome.tabs.create({ url: params.url });
      return { tabId: tab.id, url: tab.url };
    }
    
    case 'navigate': {
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!activeTab) throw new Error('No active tab');
      await chrome.tabs.update(activeTab.id, { url: params.url });
      return { tabId: activeTab.id, url: params.url };
    }
    
    case 'closeTab': {
      await chrome.tabs.remove(params.tabId);
      return { closed: true };
    }
    
    case 'activateTab': {
      await chrome.tabs.update(params.tabId, { active: true });
      return { activated: true };
    }
    
    case 'click': {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (selector) => {
          const el = document.querySelector(selector);
          if (!el) throw new Error('Element not found: ' + selector);
          el.click();
          return true;
        },
        args: [params.selector]
      });
      return results[0]?.result;
    }
    
    case 'type': {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (selector, text) => {
          const el = document.querySelector(selector);
          if (!el) throw new Error('Element not found: ' + selector);
          el.focus();
          el.value = text;
          el.dispatchEvent(new Event('input', { bubbles: true }));
          return true;
        },
        args: [params.selector, params.text]
      });
      return results[0]?.result;
    }
    
    case 'getText': {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (selector) => {
          const el = document.querySelector(selector);
          if (!el) throw new Error('Element not found: ' + selector);
          return el.innerText;
        },
        args: [params.selector]
      });
      return results[0]?.result;
    }
    
    case 'getHTML': {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (selector) => {
          const el = document.querySelector(selector);
          if (!el) throw new Error('Element not found: ' + selector);
          return el.innerHTML;
        },
        args: [params.selector]
      });
      return results[0]?.result;
    }
    
    case 'waitForSelector': {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (selector) => {
          return !!document.querySelector(selector);
        },
        args: [params.selector]
      });
      return results[0]?.result;
    }
    
    case 'selectAll': {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          // iframe 내부에서 selectAll 시도
          const iframe = document.querySelector('iframe#wysiwygTextarea_ifr, iframe.editor-frame');
          if (iframe && iframe.contentDocument) {
            iframe.contentDocument.execCommand('selectAll', false, null);
            return 'iframe';
          }
          // 일반 문서에서 selectAll
          document.execCommand('selectAll', false, null);
          return 'document';
        }
      });
      return results[0]?.result;
    }
    
    case 'insertText': {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (text) => {
          // iframe 내부 시도 우선
          const iframe = document.querySelector('iframe#wysiwygTextarea_ifr, iframe.editor-frame');
          if (iframe && iframe.contentDocument) {
            iframe.contentDocument.execCommand('insertText', false, text);
            return 'iframe';
          }
          // 현재 포커스된 요소
          const activeEl = document.activeElement;
          if (activeEl.isContentEditable || activeEl.tagName === 'TEXTAREA' || activeEl.tagName === 'INPUT') {
            document.execCommand('insertText', false, text);
            return 'active';
          }
          return false;
        },
        args: [params.text]
      });
      return results[0]?.result;
    }
    
    case 'getVersion':
      return { version: VERSION };
      
    case 'setHostname':
      await chrome.storage.local.set({ hostname: params.hostname });
      return { hostname: params.hostname };
    
    default:
      throw new Error('Unknown action: ' + action);
  }
}

function broadcastStatus(status) {
  chrome.runtime.sendMessage({ type: 'status', status, clientId }).catch(() => {});
}

async function setupKeepAlive() {
  const alarm = await chrome.alarms.get('keepAlive');
  if (!alarm) {
    chrome.alarms.create('keepAlive', { periodInMinutes: 0.4 });
  }
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'keepAlive') {
    if (!ws || ws.readyState !== WebSocket.OPEN) {
      connect();
    }
  }
});

chrome.runtime.onStartup.addListener(() => {
  setupKeepAlive();
  connect();
});

chrome.runtime.onInstalled.addListener(() => {
  setupKeepAlive();
  connect();
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'getStatus') {
    sendResponse({
      status: ws?.readyState === WebSocket.OPEN ? 'connected' : 'disconnected',
      clientId,
      version: VERSION
    });
  }
  return true;
});

console.log('[RTunnel] v' + VERSION);
setupKeepAlive();
connect();
