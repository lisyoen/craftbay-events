# LLM RP Manager

폐쇄망 LLM 운영을 위한 통합 관리 도구

## 기능

| 탭 | 기능 | 인증 | On/Off |
|----|------|------|--------|
| Key 발급 | API Key 벌크 발급 | 필요 | 고정 |
| Key 조회 | LiteLLM 실시간 조회 | 필요 | 고정 |
| 발급 이력 | 이력 관리/수동등록 | 필요 | 고정 |
| 채팅 | 이름만 입력하고 참여 | 불필요 | 설정 가능 |
| 파일 | 파일 업로드/다운로드 | 불필요 | 설정 가능 |
| 설정 | 서비스 On/Off, 계정관리 | 필요 | 고정 |

## 접속

- URL: https://llmrp.craftbay.io
- 기본 계정: admin / admin123

## 실행

```bash
npm install
npm start          # 개발
pm2 start ecosystem.config.js  # 운영
```

## 테스트

```bash
bash scripts/healthcheck.sh
node tests/api.test.js
```

## 버전
- v0.1.0: 최초 릴리즈
