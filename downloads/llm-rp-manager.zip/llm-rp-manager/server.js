const express = require('express');
const session = require('express-session');
const { Server } = require('socket.io');
const http = require('http');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const multer = require('multer');
const csv = require('csv-parse/sync');
const { stringify } = require('csv-stringify/sync');

const upload = multer({ storage: multer.memoryStorage() });

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  maxHttpBufferSize: 10 * 1024 * 1024  // 10MB (기본 1MB)
});

const PORT = process.env.PORT || 9055;
const CONFIG_FILE = path.join(__dirname, 'config.json');
const HISTORY_FILE = path.join(__dirname, 'key_history.json');
const CHAT_FILE = path.join(__dirname, 'chat_history.json');

// 설정 로드
function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8'));
    }
  } catch (e) { console.error('Config load error:', e); }
  return {
    admin: { id: 'admin', password_hash: '' },
    litellm: { server_url: '', master_key: '' },
    services: { chat_enabled: true, file_enabled: true }
  };
}

function saveConfig(config) {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
}

// 미들웨어
app.use(express.static('public'));
app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || 'llm-rp-manager-secret-' + uuidv4(),
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 }
}));

// 인증 미들웨어
function requireAuth(req, res, next) {
  if (req.session && req.session.authenticated) {
    return next();
  }
  res.status(401).json({ error: '인증이 필요합니다.' });
}

// 서비스 활성화 확인 미들웨어
function requireService(serviceName) {
  return (req, res, next) => {
    const config = loadConfig();
    if (config.services[serviceName]) {
      return next();
    }
    res.status(403).json({ error: '해당 서비스가 비활성화되어 있습니다.' });
  };
}

// ===== 인증 API =====
app.post('/auth/login', (req, res) => {
  const { id, password } = req.body;
  const config = loadConfig();

  if (id === config.admin.id && bcrypt.compareSync(password, config.admin.password_hash)) {
    req.session.authenticated = true;
    req.session.userId = id;
    res.json({ success: true });
  } else {
    res.status(401).json({ error: 'ID 또는 비밀번호가 올바르지 않습니다.' });
  }
});

app.post('/auth/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

app.get('/auth/check', (req, res) => {
  res.json({
    authenticated: !!(req.session && req.session.authenticated),
    userId: req.session?.userId || null
  });
});

// ===== 설정 API =====
app.get('/api/config', requireAuth, (req, res) => {
  const config = loadConfig();
  // master_key는 마스킹
  const safeConfig = {
    ...config,
    litellm: {
      ...config.litellm,
      master_key: config.litellm.master_key ? '********' : ''
    }
  };
  delete safeConfig.admin.password_hash;
  res.json(safeConfig);
});

app.post('/api/config', requireAuth, (req, res) => {
  try {
    const config = loadConfig();
    const { litellm, services } = req.body;

    if (litellm) {
      if (litellm.server_url !== undefined) config.litellm.server_url = litellm.server_url;
      if (litellm.master_key && litellm.master_key !== '********') {
        config.litellm.master_key = litellm.master_key;
      }
    }
    if (services) {
      if (services.chat_enabled !== undefined) config.services.chat_enabled = services.chat_enabled;
      if (services.file_enabled !== undefined) config.services.file_enabled = services.file_enabled;
    }

    saveConfig(config);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/config/password', requireAuth, (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const config = loadConfig();

    if (!bcrypt.compareSync(currentPassword, config.admin.password_hash)) {
      return res.status(400).json({ error: '현재 비밀번호가 올바르지 않습니다.' });
    }

    config.admin.password_hash = bcrypt.hashSync(newPassword, 10);
    saveConfig(config);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===== 서비스 상태 API (공개) =====
app.get('/api/status', (req, res) => {
  const config = loadConfig();
  res.json({
    services: config.services,
    version: require('./package.json').version
  });
});

// ===== Key History 관리 =====
function loadHistory() {
  try {
    if (fs.existsSync(HISTORY_FILE)) {
      return JSON.parse(fs.readFileSync(HISTORY_FILE, 'utf-8'));
    }
  } catch (e) { console.error('History load error:', e); }
  return [];
}

function saveHistory(history) {
  fs.writeFileSync(HISTORY_FILE, JSON.stringify(history, null, 2));
}

function addToHistory(records) {
  const history = loadHistory();
  history.push(...records);
  saveHistory(history);
}

// ===== LiteLLM Proxy API =====

// Team 목록 조회
app.post('/api/teams', requireAuth, async (req, res) => {
  try {
    const config = loadConfig();
    const { serverUrl, masterKey } = req.body;
    const url = serverUrl || config.litellm.server_url;
    const key = masterKey || config.litellm.master_key;

    const resp = await fetch(`${url}/team/list`, {
      headers: { 'Authorization': `Bearer ${key}` }
    });
    const data = await resp.json();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 발급된 Key 목록 조회 (LiteLLM)
app.post('/api/keys', requireAuth, async (req, res) => {
  try {
    const config = loadConfig();
    const { serverUrl, masterKey } = req.body;
    const url = serverUrl || config.litellm.server_url;
    const key = masterKey || config.litellm.master_key;

    const resp = await fetch(`${url}/key/list`, {
      headers: { 'Authorization': `Bearer ${key}` }
    });
    const data = await resp.json();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 양식 다운로드
app.get('/api/template.csv', (req, res) => {
  const template = 'email\nhong.gildong@example.com\nkim.cheolsu@example.com\nlee.younghee@example.com';
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="users_template.csv"');
  res.send(template);
});

// API Key 일괄 생성
app.post('/api/generate', requireAuth, upload.single('file'), async (req, res) => {
  try {
    const config = loadConfig();
    const { serverUrl, masterKey, teamId, teamName } = req.body;
    const url = serverUrl || config.litellm.server_url;
    const key = masterKey || config.litellm.master_key;

    if (!req.file) {
      return res.status(400).json({ error: 'CSV 파일이 필요합니다.' });
    }
    if (!url || !key) {
      return res.status(400).json({ error: 'LiteLLM 서버 설정이 필요합니다.' });
    }

    const content = req.file.buffer.toString('utf-8');
    const records = csv.parse(content, { columns: true, skip_empty_lines: true });

    const results = [];
    const historyRecords = [];

    for (const record of records) {
      const email = record.email?.trim();
      if (!email || !email.includes('@')) continue;

      try {
        // 사용자 생성
        await fetch(`${url}/user/new`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${key}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ user_id: email, user_email: email })
        });

        // Key 생성
        const keyBody = { user_id: email, key_alias: email.split('@')[0] };
        if (teamId) keyBody.team_id = teamId;

        const keyResp = await fetch(`${url}/key/generate`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${key}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(keyBody)
        });

        const keyData = await keyResp.json();
        const apiKey = keyData.key || '';

        results.push({
          email,
          api_key: apiKey,
          team: teamName || '',
          status: apiKey ? 'success' : 'error'
        });

        if (apiKey) {
          historyRecords.push({
            user: email,
            api_key: apiKey,
            team: teamName || '',
            note: '',
            created_at: new Date().toISOString(),
            source: 'bulk'
          });
        }
      } catch (err) {
        results.push({ email, api_key: '', team: '', status: 'error', error: err.message });
      }

      await new Promise(r => setTimeout(r, 100));
    }

    // 이력 저장
    if (historyRecords.length > 0) {
      addToHistory(historyRecords);
    }

    const columns = teamId ? ['email', 'api_key', 'team', 'status'] : ['email', 'api_key', 'status'];
    const output = stringify(results, { header: true, columns });

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="api_keys_result.csv"');
    res.send(output);

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// ===== 발급 이력 API =====

// 이력 조회
app.get('/api/history', requireAuth, (req, res) => {
  const history = loadHistory();
  res.json(history);
});

// 수동 등록
app.post('/api/history/add', requireAuth, (req, res) => {
  try {
    const { user, api_key, team, note } = req.body;
    if (!user || !api_key) {
      return res.status(400).json({ error: '사용자와 API Key는 필수입니다.' });
    }
    const record = {
      user,
      api_key,
      team: team || '',
      note: note || '',
      created_at: new Date().toISOString(),
      source: 'manual'
    };
    addToHistory([record]);
    res.json({ success: true, record });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 이력 삭제
app.delete('/api/history/:index', requireAuth, (req, res) => {
  try {
    const index = parseInt(req.params.index);
    const history = loadHistory();
    if (index < 0 || index >= history.length) {
      return res.status(400).json({ error: '잘못된 인덱스입니다.' });
    }
    history.splice(index, 1);
    saveHistory(history);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 이력 CSV 다운로드
app.get('/api/history/export', requireAuth, (req, res) => {
  const history = loadHistory();
  const output = stringify(history, {
    header: true,
    columns: ['user', 'api_key', 'team', 'note', 'created_at', 'source']
  });
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="api_key_history.csv"');
  res.send(output);
});

// ===== 파일 관리 =====
const UPLOAD_DIR = path.join(__dirname, 'uploads');
const MAX_FILE_SIZE = 100 * 1024 * 1024; // 100MB

// uploads 폴더 생성
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

const fileUpload = multer({
  storage: multer.diskStorage({
    destination: UPLOAD_DIR,
    filename: (req, file, cb) => {
      // 한글 파일명 처리
      const originalName = Buffer.from(file.originalname, 'latin1').toString('utf8');
      cb(null, originalName);
    }
  }),
  limits: { fileSize: MAX_FILE_SIZE }
});

// 파일 목록 조회
app.get('/api/files', requireService('file_enabled'), (req, res) => {
  try {
    const files = fs.readdirSync(UPLOAD_DIR)
      .filter(f => !f.startsWith('.'))
      .map(filename => {
        const filepath = path.join(UPLOAD_DIR, filename);
        const stats = fs.statSync(filepath);
        return {
          filename,
          size: stats.size,
          uploadedAt: stats.mtime.toISOString()
        };
      })
      .sort((a, b) => new Date(b.uploadedAt) - new Date(a.uploadedAt));
    res.json(files);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 파일 업로드
app.post('/api/files/upload', requireService('file_enabled'), fileUpload.array('files', 10), (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ error: '파일이 없습니다.' });
    }
    const uploaded = req.files.map(f => ({
      filename: f.filename,
      size: f.size
    }));
    res.json({ success: true, files: uploaded });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 파일 다운로드
app.get('/api/files/download/:filename', requireService('file_enabled'), (req, res) => {
  try {
    const filename = decodeURIComponent(req.params.filename);
    const filepath = path.join(UPLOAD_DIR, filename);

    if (!fs.existsSync(filepath)) {
      return res.status(404).json({ error: '파일을 찾을 수 없습니다.' });
    }

    // 경로 탐색 방지
    if (!filepath.startsWith(UPLOAD_DIR)) {
      return res.status(400).json({ error: '잘못된 경로입니다.' });
    }

    res.download(filepath, filename);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 파일 삭제
app.delete('/api/files/:filename', requireService('file_enabled'), (req, res) => {
  try {
    const filename = decodeURIComponent(req.params.filename);
    const filepath = path.join(UPLOAD_DIR, filename);

    if (!fs.existsSync(filepath)) {
      return res.status(404).json({ error: '파일을 찾을 수 없습니다.' });
    }

    if (!filepath.startsWith(UPLOAD_DIR)) {
      return res.status(400).json({ error: '잘못된 경로입니다.' });
    }

    fs.unlinkSync(filepath);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===== 가드레일 =====
app.get('/api/guardrail', requireAuth, (req, res) => {
  const config = loadConfig();
  res.json(config.guardrail || {});
});

app.post('/api/guardrail', requireAuth, (req, res) => {
  try {
    const config = loadConfig();
    config.guardrail = req.body;
    saveConfig(config);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/guardrail/test', requireAuth, (req, res) => {
  const { text } = req.body;
  const config = loadConfig();
  const gr = config.guardrail || {};

  let result = text;
  let masked = [];

  if (gr.pii_masking?.enabled) {
    const patterns = {
      rrn: { regex: /\d{6}-[1-4]\d{6}/g, mask: '******-*******', name: '주민번호' },
      card: { regex: /\d{4}-\d{4}-\d{4}-\d{4}/g, mask: '****-****-****-****', name: '카드번호' },
      phone: { regex: /01[0-9]-\d{3,4}-\d{4}/g, mask: '010-****-****', name: '전화번호' },
      email: { regex: /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g, mask: '***@***.***', name: '이메일' },
      account: { regex: /\d{3}-\d{6,}-\d{2}/g, mask: '***-******-**', name: '계좌번호' },
      ip: { regex: /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/g, mask: '***.***.***.***', name: 'IP주소' }
    };

    for (const [type, p] of Object.entries(patterns)) {
      if (gr.pii_masking.types?.[type]) {
        const matches = result.match(p.regex);
        if (matches) {
          masked.push({ type: p.name, count: matches.length });
          result = result.replace(p.regex, p.mask);
        }
      }
    }
  }

  let blocked = false;
  if (gr.keyword_block?.enabled && gr.keyword_block.keywords?.length) {
    for (const kw of gr.keyword_block.keywords) {
      if (text.toLowerCase().includes(kw.toLowerCase())) {
        blocked = true;
        break;
      }
    }
  }

  res.json({ original: text, result, masked, blocked, blockMessage: blocked ? gr.keyword_block.response : null });
});

// ===== 헬스체크 =====
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ===== 채팅 페이지 라우트 =====
app.get('/chat', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'chat.html'));
});

// ===== 채팅 =====
const MAX_CHAT = 50;
let chatUsers = new Map();

function loadChat() {
  try { if (fs.existsSync(CHAT_FILE)) return JSON.parse(fs.readFileSync(CHAT_FILE, 'utf-8')); }
  catch (e) {}
  return [];
}
function saveChat(h) { fs.writeFileSync(CHAT_FILE, JSON.stringify(h.slice(-MAX_CHAT), null, 2)); }
function addChat(m) { const h = loadChat(); h.push(m); saveChat(h); return m; }
function getUsers() { return Array.from(chatUsers.values()).map(u => u.username); }

app.get('/api/chat/messages', requireService('chat_enabled'), (req, res) => {
  res.json(loadChat());
});

app.post('/api/chat/clear', requireAuth, (req, res) => {
  saveChat([]);
  io.emit('chatCleared', {});
  res.json({ success: true });
});

io.on('connection', (socket) => {
  const config = loadConfig();
  if (!config.services.chat_enabled) { socket.disconnect(); return; }

  socket.on('setUsername', (username) => {
    if (!username || username.length > 20) {
      socket.emit('setUsernameResult', { success: false, error: '닉네임 1-20자' });
      return;
    }
    const old = chatUsers.get(socket.id);
    chatUsers.set(socket.id, { username, joinedAt: new Date().toISOString() });
    if (old) {
      io.emit('systemMessage', { message: `${old.username} → ${username}` });
    } else {
      io.emit('systemMessage', { message: `${username} 입장` });
      socket.emit('chatHistory', loadChat());
    }
    socket.emit('setUsernameResult', { success: true });
    io.emit('participants', getUsers());
  });

  socket.on('chatMessage', (data) => {
    const user = chatUsers.get(socket.id);
    if (!user) return;
    const msg = {
      id: Date.now().toString(),
      username: user.username,
      message: (data.message || '').slice(0, 5000),
      timestamp: new Date().toISOString(),
      type: data.type || 'text',
      filename: data.filename || null,
      url: data.url || null
    };
    addChat(msg);
    io.emit('chatMessage', msg);
  });

  socket.on('disconnect', () => {
    const user = chatUsers.get(socket.id);
    if (user) {
      io.emit('systemMessage', { message: `${user.username} 퇴장` });
      chatUsers.delete(socket.id);
      io.emit('participants', getUsers());
    }
  });
});

server.listen(PORT, () => {
  console.log(`LLM RP Manager running on port ${PORT}`);
  console.log(`URL: http://localhost:${PORT}`);
});
