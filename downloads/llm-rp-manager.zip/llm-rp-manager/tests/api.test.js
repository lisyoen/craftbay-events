const BASE = process.env.TEST_URL || 'http://localhost:9055';
let passed = 0, failed = 0;

async function test(name, fn) {
  try { await fn(); console.log('✅', name); passed++; }
  catch (e) { console.log('❌', name, '-', e.message); failed++; }
}

async function run() {
  console.log(`Testing: ${BASE}\n${'='.repeat(40)}`);

  await test('GET /health', async () => {
    const r = await fetch(`${BASE}/health`);
    if (r.status !== 200) throw Error(`Status ${r.status}`);
  });

  await test('GET /api/status', async () => {
    const r = await fetch(`${BASE}/api/status`);
    const d = await r.json();
    if (!d.services) throw Error('Missing services');
  });

  await test('GET / (main)', async () => {
    const r = await fetch(`${BASE}/`);
    const t = await r.text();
    if (!t.includes('LLM RP Manager')) throw Error('Missing title');
  });

  await test('GET /chat', async () => {
    const r = await fetch(`${BASE}/chat`);
    if (r.status !== 200) throw Error(`Status ${r.status}`);
  });

  await test('GET /auth/check (unauth)', async () => {
    const r = await fetch(`${BASE}/auth/check`);
    const d = await r.json();
    if (d.authenticated !== false) throw Error('Should be false');
  });

  await test('POST /auth/login (wrong)', async () => {
    const r = await fetch(`${BASE}/auth/login`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({id:'admin', password:'wrong'})
    });
    if (r.status !== 401) throw Error(`Expected 401, got ${r.status}`);
  });

  await test('GET /api/config (unauth)', async () => {
    const r = await fetch(`${BASE}/api/config`);
    if (r.status !== 401) throw Error(`Expected 401, got ${r.status}`);
  });

  await test('GET /api/template.csv', async () => {
    const r = await fetch(`${BASE}/api/template.csv`);
    const t = await r.text();
    if (!t.includes('email')) throw Error('Missing email');
  });

  await test('GET /api/chat/messages', async () => {
    const r = await fetch(`${BASE}/api/chat/messages`);
    if (r.status !== 200) throw Error(`Status ${r.status}`);
  });

  await test('GET /api/files', async () => {
    const r = await fetch(`${BASE}/api/files`);
    if (r.status !== 200) throw Error(`Status ${r.status}`);
  });

  console.log(`${'='.repeat(40)}\nResults: ${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
}

run().catch(e => { console.error(e); process.exit(1); });
