module.exports = {
  apps: [{
    name: 'llm-rp-manager',
    script: 'server.js',
    cwd: '/home/lisyoen/projects/llm-rp-manager',
    env: {
      NODE_ENV: 'production',
      PORT: 9055
    },
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '500M'
  }]
};
