#!/bin/bash
BASE="${1:-http://localhost:9055}"
echo "Checking $BASE ..."; echo "---"

endpoints="/health:200 /api/status:200 /:200 /chat:200 /auth/check:200 /api/template.csv:200 /api/chat/messages:200 /api/files:200 /api/config:401"
failed=0

for ep in $endpoints; do
  path="${ep%%:*}"; expected="${ep##*:}"
  status=$(curl -s -o /dev/null -w "%{http_code}" "$BASE$path")
  [ "$status" = "$expected" ] && echo "✅ $path: $status" || { echo "❌ $path: $status (expected $expected)"; failed=1; }
done

echo "---"
[ $failed -eq 0 ] && echo "✅ All passed!" || echo "❌ Some failed!"
exit $failed
